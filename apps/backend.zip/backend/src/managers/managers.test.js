"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const globals_1 = require("@jest/globals");
const managers_routes_1 = __importDefault(require("./managers.routes"));
const UserDal = __importStar(require("./manager.dal"));
// Mock the data access layer
globals_1.jest.mock('./manager.dal', () => ({
    getUsers: globals_1.jest.fn(),
    createUser: globals_1.jest.fn(),
    updateUser: globals_1.jest.fn(),
    deleteUser: globals_1.jest.fn()
}));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use('/managers', managers_routes_1.default);
describe('Manager API', () => {
    // Reset mocks before each test
    beforeEach(() => {
        globals_1.jest.resetAllMocks();
    });
    describe('GET /managers/:restaurantId', () => {
        it('should return managers for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockUsers = [
                {
                    user_id: 1,
                    username: 'testadmin',
                    email: 'test@example.com',
                    phone_number: '+1234567890',
                    role: 'manager',
                    restaurant_id: 1,
                    status: 'active',
                    created_at: '2023-01-01T00:00:00.000Z',
                    updated_at: '2023-01-01T00:00:00.000Z'
                }
            ];
            // Mock the getUsers function with proper typing
            globals_1.jest.mocked(UserDal.getUsers).mockResolvedValue(mockUsers);
            const response = yield (0, supertest_1.default)(app).get('/managers/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockUsers);
            expect(UserDal.getUsers).toHaveBeenCalledWith(1);
        }));
        it('should handle errors when fetching managers', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the getUsers function to throw an error
            globals_1.jest.mocked(UserDal.getUsers).mockRejectedValue(new Error('Database error'));
            const response = yield (0, supertest_1.default)(app).get('/managers/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Failed to retrieve users' });
        }));
    });
    describe('POST /managers', () => {
        it('should create a new manager successfully', () => __awaiter(void 0, void 0, void 0, function* () {
            const newUser = {
                username: 'newadmin',
                password: 'securepassword',
                email: 'newadmin@example.com',
                phone_number: '+1234567890',
                role: 'manager',
                restaurant_id: 1,
                status: 'active'
            };
            const mockResponse = {
                fieldCount: 0,
                affectedRows: 1,
                insertId: 4,
                serverStatus: 2,
                warningCount: 0,
                message: '',
                protocol41: true,
                changedRows: 0
            };
            // Mock the createUser function
            globals_1.jest.mocked(UserDal.createUser).mockResolvedValue(mockResponse);
            const response = yield (0, supertest_1.default)(app)
                .post('/managers')
                .send(newUser);
            expect(response.status).toBe(201);
            expect(response.body).toEqual(mockResponse);
            expect(UserDal.createUser).toHaveBeenCalledWith(newUser);
        }));
        it('should handle validation errors when creating a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            const invalidUser = {
                username: '',
                password: '',
                email: '',
                phone_number: '',
                role: '',
                restaurant_id: 1,
                status: 'active'
            };
            const response = yield (0, supertest_1.default)(app)
                .post('/managers')
                .send(invalidUser);
            expect(response.status).toBe(400);
            expect(response.body).toHaveProperty('errors');
            expect(response.body.errors.length).toBeGreaterThan(0);
            expect(UserDal.createUser).not.toHaveBeenCalled();
        }));
        it('should handle server errors when creating a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            const newUser = {
                username: 'newadmin',
                password: 'securepassword',
                email: 'newadmin@example.com',
                phone_number: '+1234567890',
                role: 'manager',
                restaurant_id: 1,
                status: 'active'
            };
            // Mock the createUser function to throw an error
            globals_1.jest.mocked(UserDal.createUser).mockRejectedValue(new Error('Database error'));
            const response = yield (0, supertest_1.default)(app)
                .post('/managers')
                .send(newUser);
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Failed to create user' });
        }));
    });
    describe('PUT /managers/:userId', () => {
        it('should update a manager successfully', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedUser = {
                username: 'updatedadmin',
                password: 'newsecurepassword',
                email: 'updatedadmin@example.com',
                phone_number: '+0987654321',
                role: 'manager',
                restaurant_id: 1,
                status: 'active'
            };
            const mockResponse = {
                fieldCount: 0,
                affectedRows: 1,
                insertId: 0,
                serverStatus: 2,
                warningCount: 0,
                message: '(Rows matched: 1 Changed: 1)',
                protocol41: true,
                changedRows: 1
            };
            // Mock the updateUser function
            globals_1.jest.mocked(UserDal.updateUser).mockResolvedValue(mockResponse);
            const response = yield (0, supertest_1.default)(app)
                .put('/managers/1')
                .send(updatedUser);
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockResponse);
            expect(UserDal.updateUser).toHaveBeenCalledWith(1, updatedUser);
        }));
        it('should handle validation errors when updating a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            const invalidUser = {
                username: '',
                password: '',
                email: '',
                phone_number: '',
                role: '',
                restaurant_id: 1,
                status: 'active'
            };
            const response = yield (0, supertest_1.default)(app)
                .put('/managers/1')
                .send(invalidUser);
            expect(response.status).toBe(400);
            expect(response.body).toHaveProperty('errors');
            expect(response.body.errors.length).toBeGreaterThan(0);
            expect(UserDal.updateUser).not.toHaveBeenCalled();
        }));
        it('should handle not found errors when updating a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedUser = {
                username: 'updatedadmin',
                password: 'newsecurepassword',
                email: 'updatedadmin@example.com',
                phone_number: '+0987654321',
                role: 'manager',
                restaurant_id: 1,
                status: 'active'
            };
            // Mock the updateUser function to return null (user not found)
            globals_1.jest.mocked(UserDal.updateUser).mockResolvedValue(null);
            const response = yield (0, supertest_1.default)(app)
                .put('/managers/999')
                .send(updatedUser);
            expect(response.status).toBe(404);
            expect(response.body).toEqual({ message: 'User not found' });
        }));
        it('should handle server errors when updating a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedUser = {
                username: 'updatedadmin',
                password: 'newsecurepassword',
                email: 'updatedadmin@example.com',
                phone_number: '+0987654321',
                role: 'manager',
                restaurant_id: 1,
                status: 'active'
            };
            // Mock the updateUser function to throw an error
            globals_1.jest.mocked(UserDal.updateUser).mockRejectedValue(new Error('Database error'));
            const response = yield (0, supertest_1.default)(app)
                .put('/managers/1')
                .send(updatedUser);
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Failed to update user' });
        }));
    });
    describe('DELETE /managers/:userId', () => {
        it('should delete a manager successfully', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockResponse = {
                fieldCount: 0,
                affectedRows: 1,
                insertId: 0,
                serverStatus: 2,
                warningCount: 0,
                message: '',
                protocol41: true,
                changedRows: 0
            };
            // Mock the deleteUser function
            globals_1.jest.mocked(UserDal.deleteUser).mockResolvedValue(mockResponse);
            const response = yield (0, supertest_1.default)(app).delete('/managers/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual({ message: 'User deleted successfully' });
            expect(UserDal.deleteUser).toHaveBeenCalledWith(1);
        }));
        it('should handle not found errors when deleting a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the deleteUser function to return null (user not found)
            globals_1.jest.mocked(UserDal.deleteUser).mockResolvedValue(null);
            const response = yield (0, supertest_1.default)(app).delete('/managers/999');
            expect(response.status).toBe(404);
            expect(response.body).toEqual({ message: 'User not found' });
        }));
        it('should handle server errors when deleting a manager', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the deleteUser function to throw an error
            globals_1.jest.mocked(UserDal.deleteUser).mockRejectedValue(new Error('Database error'));
            const response = yield (0, supertest_1.default)(app).delete('/managers/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Failed to delete user' });
        }));
    });
});
