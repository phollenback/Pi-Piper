"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("@jest/globals");
const pg_connector_1 = require("../services/pg.connector");
// Global setup for all tests
beforeAll(() => __awaiter(void 0, void 0, void 0, function* () {
    if (process.env.NODE_ENV !== 'test') {
        console.log('Initializing database connection...');
        yield (0, pg_connector_1.initializeMySqlConnector)();
        console.log('Database connection initialized.');
    }
}));
// Global teardown for all tests
afterAll(() => __awaiter(void 0, void 0, void 0, function* () {
    // Ensure all async operations are complete
}));
// Reset mocks before each test
beforeEach(() => {
    globals_1.jest.clearAllMocks();
});
