"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const connection_1 = require("../db/connection");
const ingredient_service_1 = require("../services/ingredient.service");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const dotenv_1 = __importDefault(require("dotenv"));
// Load environment variables from .env file
dotenv_1.default.config();
// This is an integration test that tests the inventory tracking system with real database interactions
// To run this test, you need to have a test database set up with the required tables and data
describe('Inventory Tracking Integration Tests', () => {
    // Test data
    const testRestaurantId = 999;
    const testIngredientId = 9999;
    const testPrepItemId = 9999;
    const testIngredientName = 'Test Ingredient';
    const testPrepItemName = 'Test Prep Item';
    // Setup test data before tests
    beforeAll(() => __awaiter(void 0, void 0, void 0, function* () {
        try {
            // Create test ingredient
            yield connection_1.db.insert(schema_1.dimIngredient).values({
                ingredientId: testIngredientId,
                ingredientName: testIngredientName,
                restaurantId: testRestaurantId,
                unit: 'units',
                unitPrice: '1.00',
                parLevel: '10',
                currentStock: '10',
                reorderPoint: '2',
                isActive: true
            });
            // Create test prep item
            yield connection_1.db.insert(schema_1.dimPrepItem).values({
                prepItemId: testPrepItemId,
                name: testPrepItemName,
                restaurantId: testRestaurantId,
                kitchenDepartmentId: 1
            });
            // Create test inventory record
            yield connection_1.db.insert(schema_1.factInventory).values({
                ingredientId: testIngredientId,
                restaurantId: testRestaurantId,
                dateId: parseInt(new Date().toISOString().split('T')[0].replace(/-/g, '')),
                quantity: '10',
                unit: 'units'
            });
            // Create test prep item ingredient relationship
            yield connection_1.db.insert(schema_1.factPrepItemIngredients).values({
                prepItemId: testPrepItemId,
                ingredientId: testIngredientId,
                quantity: '5',
                unit: 'units'
            });
        }
        catch (error) {
            console.error('Error setting up test data:', error);
        }
    }));
    // Clean up test data after tests
    afterAll(() => __awaiter(void 0, void 0, void 0, function* () {
        try {
            // Delete test data
            yield connection_1.db.delete(schema_1.factInventoryTransaction)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, testRestaurantId)));
            yield connection_1.db.delete(schema_1.factPrepItemIngredients)
                .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, testPrepItemId));
            yield connection_1.db.delete(schema_1.factInventory)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
            yield connection_1.db.delete(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, testPrepItemId));
            yield connection_1.db.delete(schema_1.dimIngredient)
                .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, testIngredientId));
        }
        catch (error) {
            console.error('Error cleaning up test data:', error);
        }
    }));
    // Reset inventory quantity before each test
    beforeEach(() => __awaiter(void 0, void 0, void 0, function* () {
        try {
            yield connection_1.db.update(schema_1.factInventory)
                .set({ quantity: '10' })
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        }
        catch (error) {
            console.error('Error resetting inventory quantity:', error);
        }
    }));
    it('should update inventory when completing a prep item', () => __awaiter(void 0, void 0, void 0, function* () {
        // Complete the prep item
        const result = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
        // Check that the operation was successful
        expect(result.success).toBe(true);
        // Check that the inventory was updated
        const updatedInventory = yield connection_1.db.select({ quantity: schema_1.factInventory.quantity })
            .from(schema_1.factInventory)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        expect(updatedInventory[0].quantity).toBe('5'); // 10 - 5 = 5
        // Check that a transaction was recorded
        const transactions = yield connection_1.db.select()
            .from(schema_1.factInventoryTransaction)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, testRestaurantId)));
        expect(transactions.length).toBe(1);
        expect(transactions[0].quantityChange).toBe('-5');
        expect(transactions[0].previousQuantity).toBe('10');
        expect(transactions[0].newQuantity).toBe('5');
        expect(transactions[0].transactionType).toBe('prep');
    }));
    it('should handle inventory going below zero by setting it to zero', () => __awaiter(void 0, void 0, void 0, function* () {
        // Set the prep item to require more than available inventory
        yield connection_1.db.update(schema_1.factPrepItemIngredients)
            .set({ quantity: '15' }) // Requires 15, but only 10 available
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, testPrepItemId), (0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.ingredientId, testIngredientId)));
        // Complete the prep item
        const result = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
        // Check that the operation was successful but with a warning
        expect(result.success).toBe(true);
        expect(result.message).toContain('Warning: Test Ingredient inventory would go below zero');
        // Check that the inventory was set to zero, not negative
        const updatedInventory = yield connection_1.db.select({ quantity: schema_1.factInventory.quantity })
            .from(schema_1.factInventory)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        expect(updatedInventory[0].quantity).toBe('0');
        // Check that a transaction was recorded with the adjustment
        const transactions = yield connection_1.db.select()
            .from(schema_1.factInventoryTransaction)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, testRestaurantId)))
            .orderBy((0, drizzle_orm_1.desc)(schema_1.factInventoryTransaction.transactionId))
            .limit(1);
        expect(transactions[0].quantityChange).toBe('-15');
        expect(transactions[0].previousQuantity).toBe('10');
        expect(transactions[0].newQuantity).toBe('0');
        expect(transactions[0].notes).toContain('(Adjusted to prevent negative inventory)');
        // Reset the prep item quantity for other tests
        yield connection_1.db.update(schema_1.factPrepItemIngredients)
            .set({ quantity: '5' })
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, testPrepItemId), (0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.ingredientId, testIngredientId)));
    }));
    it('should provide a warning when inventory reaches zero exactly', () => __awaiter(void 0, void 0, void 0, function* () {
        // Set inventory to exactly match the required amount
        yield connection_1.db.update(schema_1.factInventory)
            .set({ quantity: '5' })
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        // Complete the prep item
        const result = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
        // Check that the operation was successful but with a warning
        expect(result.success).toBe(true);
        expect(result.message).toContain('Alert: Test Ingredient is now out of stock');
        // Check that the inventory is zero
        const updatedInventory = yield connection_1.db.select({ quantity: schema_1.factInventory.quantity })
            .from(schema_1.factInventory)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        expect(updatedInventory[0].quantity).toBe('0');
    }));
    it('should provide a warning when inventory is running low', () => __awaiter(void 0, void 0, void 0, function* () {
        // Set inventory to a level where it will be low after the update
        yield connection_1.db.update(schema_1.factInventory)
            .set({ quantity: '7' })
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        // Complete the prep item
        const result = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
        // Check that the operation was successful but with a warning
        expect(result.success).toBe(true);
        expect(result.message).toContain('Alert: Test Ingredient is running low (2 remaining)');
        // Check that the inventory is low but not zero
        const updatedInventory = yield connection_1.db.select({ quantity: schema_1.factInventory.quantity })
            .from(schema_1.factInventory)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, testIngredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, testRestaurantId)));
        expect(updatedInventory[0].quantity).toBe('2');
    }));
});
