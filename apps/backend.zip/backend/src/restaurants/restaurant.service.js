"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestaurantService = void 0;
const restaurant_dao_1 = require("./restaurant.dao");
const ingredient_service_1 = require("../services/ingredient.service");
class RestaurantService {
    static getAllRestaurants() {
        return __awaiter(this, void 0, void 0, function* () {
            // Implementation to get all restaurants
            const restaurants = yield (0, restaurant_dao_1.getRestaurants)();
            return restaurants;
        });
    }
    static getRestaurantById(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            const restaurant = yield (0, restaurant_dao_1.getRestaurantById)(restaurantId);
            return restaurant;
        });
    }
    static getRestaurantDetails(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get comprehensive details for a single restaurant
            const restaurant = yield (0, restaurant_dao_1.getRestaurantById)(restaurantId);
            if (!restaurant) {
                throw new Error(`Restaurant with ID ${restaurantId} not found`);
            }
            // Get inventory status
            const inventoryStatus = yield ingredient_service_1.IngredientService.getInventoryStatus(restaurantId);
            // Calculate inventory metrics
            const outOfStockCount = inventoryStatus.filter(item => item.quantityAfter === null || item.quantityAfter === '0.00' || parseFloat(item.quantityAfter) === 0).length;
            const lowStockCount = inventoryStatus.filter(item => {
                if (item.quantityAfter === null || item.quantityAfter === '0.00' || parseFloat(item.quantityAfter) === 0) {
                    return false;
                }
                const quantity = parseFloat(item.quantityAfter);
                const threshold = item.quantityThreshold || 0;
                return quantity <= threshold;
            }).length;
            // Return comprehensive restaurant details
            return {
                restaurant,
                metrics: {
                    inventory: {
                        totalItems: inventoryStatus.length,
                        outOfStock: outOfStockCount,
                        lowStock: lowStockCount,
                        inStock: inventoryStatus.length - outOfStockCount - lowStockCount
                    }
                }
            };
        });
    }
    static getRestaurantComparison(restaurantIds) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get comparison data for multiple restaurants
            const comparisonData = {
                restaurants: [],
                inventoryComparison: [],
                prepComparison: [],
                performanceMetrics: []
            };
            // Get basic restaurant info
            for (const id of restaurantIds) {
                const restaurant = yield (0, restaurant_dao_1.getRestaurantById)(id);
                if (restaurant) {
                    comparisonData.restaurants.push(restaurant);
                }
            }
            // Additional comparison data would be fetched here
            // This would involve calling other services to get inventory, prep, and performance data
            return comparisonData;
        });
    }
}
exports.RestaurantService = RestaurantService;
