"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const restaurant_controller_1 = require("./restaurant.controller");
const asyncHandler_1 = __importDefault(require("../util/asyncHandler"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const router = (0, express_1.Router)();
router.use(winston_middleware_1.responseTimeLogger);
router.use(winston_middleware_1.requestLogger);
router
    .route('/')
    .get((0, asyncHandler_1.default)(restaurant_controller_1.readRestaurants));
router
    .route('/:restaurantId')
    .get((0, asyncHandler_1.default)(restaurant_controller_1.readRestaurantById));
// Get detailed information for a single restaurant
router
    .route('/details/:restaurantId')
    .get((0, asyncHandler_1.default)(restaurant_controller_1.getRestaurantDetails));
// New route for restaurant comparison
router
    .route('/compare')
    .post((0, asyncHandler_1.default)(restaurant_controller_1.compareRestaurants));
exports.default = router;
