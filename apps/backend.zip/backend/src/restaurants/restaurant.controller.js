"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.compareRestaurants = exports.getRestaurantDetails = exports.readRestaurantById = exports.readRestaurants = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const drizzle_orm_1 = require("drizzle-orm");
const schema_1 = require("../db/schema");
const connection_1 = require("../db/connection");
const restaurant_service_1 = require("./restaurant.service");
const readRestaurants = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.controller][readRestaurants][START]');
    try {
        const restaurants = yield connection_1.db.select().from(schema_1.dimRestaurant);
        winston_middleware_1.logger.info('[restaurant.controller][readRestaurants][SUCCESS]', { restaurants });
        res.status(200).json(restaurants);
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.controller][readRestaurants][ERROR]', { error });
        res.status(500).json({
            message: 'Failed to fetch restaurants',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
});
exports.readRestaurants = readRestaurants;
const readRestaurantById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { restaurantId } = req.params;
    const restaurant = yield connection_1.db.select().from(schema_1.dimRestaurant).where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.restaurantId, Number(restaurantId)));
    res.json(restaurant);
});
exports.readRestaurantById = readRestaurantById;
const getRestaurantDetails = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.controller][getRestaurantDetails][START]');
    try {
        const { restaurantId } = req.params;
        if (!restaurantId) {
            return res.status(400).json({
                message: 'Restaurant ID is required'
            });
        }
        const details = yield restaurant_service_1.RestaurantService.getRestaurantDetails(Number(restaurantId));
        winston_middleware_1.logger.info('[restaurant.controller][getRestaurantDetails][SUCCESS]', {
            restaurantId
        });
        res.status(200).json(details);
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.controller][getRestaurantDetails][ERROR]', { error });
        res.status(500).json({
            message: 'Failed to get restaurant details',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
});
exports.getRestaurantDetails = getRestaurantDetails;
const compareRestaurants = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.controller][compareRestaurants][START]');
    try {
        const { restaurantIds } = req.body;
        if (!restaurantIds || !Array.isArray(restaurantIds) || restaurantIds.length === 0) {
            return res.status(400).json({
                message: 'Invalid request. Please provide an array of restaurant IDs.'
            });
        }
        // Convert string IDs to numbers if needed
        const numericIds = restaurantIds.map(id => typeof id === 'string' ? parseInt(id, 10) : id);
        const comparisonData = yield restaurant_service_1.RestaurantService.getRestaurantComparison(numericIds);
        winston_middleware_1.logger.info('[restaurant.controller][compareRestaurants][SUCCESS]', {
            restaurantCount: comparisonData.restaurants.length
        });
        res.status(200).json(comparisonData);
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.controller][compareRestaurants][ERROR]', { error });
        res.status(500).json({
            message: 'Failed to compare restaurants',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
});
exports.compareRestaurants = compareRestaurants;
