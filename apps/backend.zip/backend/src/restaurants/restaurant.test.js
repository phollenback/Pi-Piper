"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const restaurant_routes_1 = __importDefault(require("./restaurant.routes"));
const RestaurantController = __importStar(require("./restaurant.controller"));
// Mock the restaurant controller
jest.mock('./restaurant.controller', () => ({
    readRestaurants: jest.fn()
}));
// Mock database connection
jest.mock('../db/connection', () => ({
    query: jest.fn()
}));
describe('Restaurant API', () => {
    let app;
    beforeEach(() => {
        app = (0, express_1.default)();
        app.use(express_1.default.json());
        app.use('/restaurants', restaurant_routes_1.default);
        jest.clearAllMocks();
    });
    describe('GET /restaurants', () => {
        it('should return all restaurants', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockRestaurants = [
                { id: 1, name: 'Test Restaurant 1', location: 'Test Location 1' },
                { id: 2, name: 'Test Restaurant 2', location: 'Test Location 2' }
            ];
            RestaurantController.readRestaurants.mockImplementation((req, res) => {
                res.status(200).json(mockRestaurants);
            });
            const response = yield (0, supertest_1.default)(app).get('/restaurants');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockRestaurants);
            expect(RestaurantController.readRestaurants).toHaveBeenCalled();
        }));
        it('should handle errors when fetching restaurants', () => __awaiter(void 0, void 0, void 0, function* () {
            RestaurantController.readRestaurants.mockImplementation((req, res) => {
                res.status(500).json({ message: 'Error fetching restaurants' });
            });
            const response = yield (0, supertest_1.default)(app).get('/restaurants');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Error fetching restaurants' });
            expect(RestaurantController.readRestaurants).toHaveBeenCalled();
        }));
    });
});
