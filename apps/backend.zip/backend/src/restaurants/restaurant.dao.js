"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteRestaurant = exports.updateRestaurant = exports.createRestaurant = exports.getRestaurantById = exports.getRestaurants = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const getRestaurants = () => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.dao][getRestaurants][START]');
    try {
        const restaurants = yield connection_1.db.select()
            .from(schema_1.dimRestaurant);
        winston_middleware_1.logger.info('[restaurant.dao][getRestaurants][SUCCESS]');
        return restaurants;
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.dao][getRestaurants][ERROR]', { error });
        throw error;
    }
});
exports.getRestaurants = getRestaurants;
const getRestaurantById = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.dao][getRestaurantById][START]', { restaurantId });
    try {
        const restaurants = yield connection_1.db.select()
            .from(schema_1.dimRestaurant)
            .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.restaurantId, restaurantId))
            .limit(1);
        const restaurant = restaurants[0];
        winston_middleware_1.logger.info('[restaurant.dao][getRestaurantById][SUCCESS]', { restaurant });
        return restaurant;
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.dao][getRestaurantById][ERROR]', { error, restaurantId });
        throw error;
    }
});
exports.getRestaurantById = getRestaurantById;
const createRestaurant = (restaurantData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.dao][createRestaurant][START]', { restaurantData });
    try {
        yield connection_1.db.insert(schema_1.dimRestaurant)
            .values(restaurantData);
        // Get the newly created restaurant by name (since we don't have the ID)
        const restaurants = yield connection_1.db.select()
            .from(schema_1.dimRestaurant)
            .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.restaurantName, restaurantData.restaurantName))
            .limit(1);
        const newRestaurant = restaurants[0];
        if (!newRestaurant) {
            throw new Error('Failed to retrieve created restaurant');
        }
        winston_middleware_1.logger.info('[restaurant.dao][createRestaurant][SUCCESS]', { newRestaurant });
        return newRestaurant;
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.dao][createRestaurant][ERROR]', { error, restaurantData });
        throw error;
    }
});
exports.createRestaurant = createRestaurant;
const updateRestaurant = (restaurantId, restaurantData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.dao][updateRestaurant][START]', { restaurantId, restaurantData });
    try {
        yield connection_1.db.update(schema_1.dimRestaurant)
            .set(restaurantData)
            .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.restaurantId, restaurantId));
        // Get the updated restaurant
        const updatedRestaurant = yield (0, exports.getRestaurantById)(restaurantId);
        if (!updatedRestaurant) {
            throw new Error('Failed to retrieve updated restaurant');
        }
        winston_middleware_1.logger.info('[restaurant.dao][updateRestaurant][SUCCESS]', { updatedRestaurant });
        return updatedRestaurant;
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.dao][updateRestaurant][ERROR]', { error, restaurantId, restaurantData });
        throw error;
    }
});
exports.updateRestaurant = updateRestaurant;
const deleteRestaurant = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[restaurant.dao][deleteRestaurant][START]', { restaurantId });
    try {
        yield connection_1.db.delete(schema_1.dimRestaurant)
            .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.restaurantId, restaurantId));
        winston_middleware_1.logger.info('[restaurant.dao][deleteRestaurant][SUCCESS]', { restaurantId });
        return true;
    }
    catch (error) {
        winston_middleware_1.logger.error('[restaurant.dao][deleteRestaurant][ERROR]', { error, restaurantId });
        throw error;
    }
});
exports.deleteRestaurant = deleteRestaurant;
