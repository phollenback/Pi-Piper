"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.restaurantQueries = void 0;
exports.restaurantQueries = {
    getRestaurants: `
    SELECT * FROM dim_restaurant;
    `
};
