"use strict";
/**
 * Winston logger middleware
 *
 * This module provides logging middleware for Express using Winston.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorLogger = exports.responseTimeLogger = exports.requestLogger = exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
const path_1 = __importDefault(require("path"));
// Create logs directory if it doesn't exist
const logsDir = path_1.default.join(__dirname, '../../logs');
require('fs').existsSync(logsDir) || require('fs').mkdirSync(logsDir);
// Configure the logger
exports.logger = winston_1.default.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston_1.default.format.combine(winston_1.default.format.timestamp(), winston_1.default.format.json()),
    defaultMeta: { service: 'pi-piper-backend' },
    transports: [
        // Console transport for development
        new winston_1.default.transports.Console({
            format: winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.simple())
        }),
        // File transports for all environments
        new winston_1.default.transports.File({
            filename: path_1.default.join(logsDir, 'error.log'),
            level: 'error',
            maxsize: 5242880, // 5MB
            maxFiles: 5
        }),
        new winston_1.default.transports.File({
            filename: path_1.default.join(logsDir, 'combined.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 5
        })
    ]
});
// Middleware to log requests
const requestLogger = (req, res, next) => {
    exports.logger.info('Incoming request', {
        method: req.method,
        url: req.url,
        ip: req.ip,
        params: req.params,
        query: req.query,
        body: req.method === 'POST' || req.method === 'PUT' ? req.body : undefined
    });
    next();
};
exports.requestLogger = requestLogger;
// Middleware to log response time
const responseTimeLogger = (req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        exports.logger.info('Request completed', {
            method: req.method,
            url: req.url,
            statusCode: res.statusCode,
            duration: `${duration}ms`
        });
    });
    next();
};
exports.responseTimeLogger = responseTimeLogger;
// Error logger (no longer needed as main logger handles errors)
exports.errorLogger = exports.logger;
