"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyJWT = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const winston_middleware_1 = require("./winston.middleware");
const verifyJWT = (req, res, next) => {
    var _a;
    try {
        const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
        if (!token) {
            res.status(401).json({ message: 'No token provided' });
            return;
        }
        const decoded = jsonwebtoken_1.default.verify(token, process.env.NEXTAUTH_SECRET);
        // Add expiration check
        if (decoded.exp && Date.now() >= decoded.exp * 1000) {
            res.status(401).json({ message: 'Token expired' });
            return;
        }
        // Cast to AuthRequest to add user property
        req.user = decoded;
        next();
    }
    catch (error) {
        winston_middleware_1.logger.error('[jwt.middleware] Token verification failed:', error);
        res.status(401).json({ message: 'Invalid token' });
    }
};
exports.verifyJWT = verifyJWT;
