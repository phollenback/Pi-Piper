"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rollbackTransaction = exports.commitTransaction = exports.beginTransaction = exports.execute = exports.pool = exports.initializeMySqlConnector = void 0;
const mysql_1 = require("mysql");
let pool = null;
exports.pool = pool;
const initializeMySqlConnector = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        exports.pool = pool = (0, mysql_1.createPool)({
            host: process.env.MY_SQL_DB_HOST,
            user: process.env.MY_SQL_DB_USER,
            password: process.env.MY_SQL_DB_PASSWORD,
            port: Number(process.env.MY_SQL_DB_PORT),
            database: process.env.MY_SQL_DB_DATABASE,
            connectionLimit: Number(process.env.MY_SQL_DB_CONNECTION_LIMIT)
        });
        console.debug('MySQL Adapter Pool generated successfully');
        console.log('process.env.DB_MY_SQL_DATABASE', process.env.MY_SQL_DB_DATABASE);
        pool.getConnection((err, connection) => {
            if (err) {
                console.log('error mysql failed to connect');
                throw new Error('not able to connect to database');
            }
            else {
                console.log('connection made');
                connection.release();
            }
        });
    }
    catch (error) {
        console.error('[mysql.connector][initializeMySqlConnector][Error]: ', error);
        throw new Error('Failed to initialize pool');
    }
});
exports.initializeMySqlConnector = initializeMySqlConnector;
const execute = (query, params, client) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!pool) {
            throw new Error('Pool not initialized');
        }
        return new Promise((resolve, reject) => {
            if (client) {
                client.query(query, params, (error, results) => {
                    if (error)
                        return reject(error);
                    resolve(results);
                });
            }
            else {
                pool.query(query, params, (error, results) => {
                    if (error)
                        return reject(error);
                    resolve(results);
                });
            }
        });
    }
    catch (error) {
        throw error;
    }
});
exports.execute = execute;
const beginTransaction = () => __awaiter(void 0, void 0, void 0, function* () {
    if (!pool)
        throw new Error('Pool not initialized');
    return new Promise((resolve, reject) => {
        pool === null || pool === void 0 ? void 0 : pool.getConnection((err, connection) => {
            if (err)
                return reject(err);
            connection.beginTransaction(err => {
                if (err)
                    return reject(err);
                resolve(connection);
            });
        });
    });
});
exports.beginTransaction = beginTransaction;
const commitTransaction = (connection) => __awaiter(void 0, void 0, void 0, function* () {
    return new Promise((resolve, reject) => {
        connection.commit((err) => {
            if (err) {
                connection.rollback(() => reject(err));
            }
            else {
                connection.release();
                resolve(true);
            }
        });
    });
});
exports.commitTransaction = commitTransaction;
const rollbackTransaction = (connection) => __awaiter(void 0, void 0, void 0, function* () {
    return new Promise((resolve, reject) => {
        connection.rollback(() => {
            connection.release();
            resolve(true);
        });
    });
});
exports.rollbackTransaction = rollbackTransaction;
