"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IngredientService = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const winston_middleware_1 = require("../middleware/winston.middleware");
class IngredientService {
    static completePrepItem(prepItemId, restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield connection_1.db.transaction((tx) => __awaiter(this, void 0, void 0, function* () {
                var _a;
                // Get the required ingredients and quantities for the prep item
                const ingredients = yield tx.select()
                    .from(schema_1.factPrepItemIngredients)
                    .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
                // Update the inventory for each ingredient
                for (const ingredient of ingredients) {
                    // Get current quantity before update
                    const currentInventory = yield tx.select({ quantity: schema_1.factInventory.quantity })
                        .from(schema_1.factInventory)
                        .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredient.ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
                    const currentQuantity = ((_a = currentInventory[0]) === null || _a === void 0 ? void 0 : _a.quantity) ? Number(currentInventory[0].quantity) : 0;
                    const requiredQuantity = Number(ingredient.quantity);
                    // Check if there's enough inventory
                    if (currentQuantity < requiredQuantity) {
                        throw new Error(`Insufficient stock for ingredient ${ingredient.ingredientId}. Required: ${requiredQuantity}, Available: ${currentQuantity}`);
                    }
                    yield tx.update(schema_1.factInventory)
                        .set({
                        quantity: (0, drizzle_orm_1.sql) `quantity - ${ingredient.quantity}`
                    })
                        .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredient.ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
                }
            }));
        });
    }
    static getInventoryStatus(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const inventoryData = yield connection_1.db.select({
                    ingredientId: schema_1.dimIngredient.ingredientId,
                    ingredientName: schema_1.dimIngredient.ingredientName,
                    quantity: schema_1.factInventory.quantity,
                    quantityThreshold: schema_1.dimIngredient.reorderPoint,
                    unit: schema_1.dimIngredient.unit,
                    maxStock: schema_1.dimIngredient.parLevel,
                    lastUpdated: schema_1.dimIngredient.updatedAt
                })
                    .from(schema_1.dimIngredient)
                    .leftJoin(schema_1.factInventory, (0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, schema_1.factInventory.ingredientId))
                    .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId));
                return inventoryData;
            }
            catch (error) {
                console.error('Error fetching inventory status:', error);
                throw new Error('Failed to fetch inventory status');
            }
        });
    }
    static updateIngredientThreshold(ingredientId, restaurantId, newThreshold) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield connection_1.db.update(schema_1.dimIngredient)
                    .set({ reorderPoint: String(newThreshold) })
                    .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)));
            }
            catch (error) {
                console.error('Error updating ingredient threshold:', error);
                throw new Error('Failed to update ingredient threshold');
            }
        });
    }
    static getLowStockIngredients(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const lowStockItems = yield connection_1.db.select({
                    ingredientId: schema_1.dimIngredient.ingredientId,
                    ingredientName: schema_1.dimIngredient.ingredientName,
                    quantity: schema_1.factInventory.quantity,
                    quantityThreshold: schema_1.dimIngredient.reorderPoint,
                    unit: schema_1.dimIngredient.unit,
                    maxStock: schema_1.dimIngredient.parLevel,
                    lastUpdated: schema_1.dimIngredient.updatedAt
                })
                    .from(schema_1.dimIngredient)
                    .leftJoin(schema_1.factInventory, (0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, schema_1.factInventory.ingredientId))
                    .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId), (0, drizzle_orm_1.lte)(schema_1.factInventory.quantity, schema_1.dimIngredient.reorderPoint)));
                return lowStockItems;
            }
            catch (error) {
                console.error('Error fetching low stock ingredients:', error);
                throw new Error('Failed to fetch low stock ingredients');
            }
        });
    }
    static updateInventoryFromPrepItem(prepItemId, restaurantId, status) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            try {
                // If the prep item is not completed, do nothing
                if (status !== 'complete') {
                    return { success: true };
                }
                // Get the ingredients for this prep item
                const ingredients = yield connection_1.db.select()
                    .from(schema_1.factPrepItemIngredients)
                    .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
                // Process ingredients and update inventory
                const warnings = [];
                for (const ingredient of ingredients) {
                    // Get current quantity before update
                    const currentInventory = yield connection_1.db.select({
                        quantity: schema_1.factInventory.quantity,
                        ingredientName: schema_1.dimIngredient.ingredientName
                    })
                        .from(schema_1.factInventory)
                        .innerJoin(schema_1.dimIngredient, (0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, schema_1.dimIngredient.ingredientId))
                        .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredient.ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
                    const ingredientName = ((_a = currentInventory[0]) === null || _a === void 0 ? void 0 : _a.ingredientName) || `Ingredient #${ingredient.ingredientId}`;
                    const previousQuantity = ((_b = currentInventory[0]) === null || _b === void 0 ? void 0 : _b.quantity) ? Number(currentInventory[0].quantity) : 0;
                    const quantityChange = -Number(ingredient.quantity);
                    let newQuantity = previousQuantity + quantityChange;
                    // Check if inventory would go below zero
                    if (newQuantity < 0) {
                        const warning = `Warning: ${ingredientName} inventory would go below zero. Setting to 0.`;
                        warnings.push(warning);
                        winston_middleware_1.logger.warn(warning, {
                            ingredientId: ingredient.ingredientId,
                            previousQuantity,
                            quantityChange,
                            attemptedNewQuantity: newQuantity
                        });
                        newQuantity = 0;
                    }
                    // Check if inventory is at zero
                    if (newQuantity === 0) {
                        const warning = `Alert: ${ingredientName} is now out of stock.`;
                        warnings.push(warning);
                        winston_middleware_1.logger.warn(warning, { ingredientId: ingredient.ingredientId });
                    }
                    // Check if inventory is low (below 20% of par level)
                    else if (newQuantity <= 2) {
                        const warning = `Alert: ${ingredientName} is running low (${newQuantity} remaining).`;
                        warnings.push(warning);
                        winston_middleware_1.logger.warn(warning, { ingredientId: ingredient.ingredientId, currentStock: newQuantity });
                    }
                    // Update inventory with the corrected quantity
                    yield connection_1.db.update(schema_1.factInventory)
                        .set({
                        quantity: String(newQuantity)
                    })
                        .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredient.ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
                    // Log the transaction in the factInventoryTransaction table
                    yield connection_1.db.insert(schema_1.factInventoryTransaction).values({
                        ingredientId: ingredient.ingredientId,
                        restaurantId,
                        dateId: parseInt(new Date().toISOString().split('T')[0].replace(/-/g, '')),
                        quantityChange: String(quantityChange),
                        transactionType: 'prep',
                        referenceId: prepItemId,
                        previousQuantity: String(previousQuantity),
                        newQuantity: String(newQuantity),
                        notes: `Used in prep item #${prepItemId}${newQuantity < previousQuantity + quantityChange ? ' (Adjusted to prevent negative inventory)' : ''}`
                    });
                }
                return {
                    success: true,
                    message: warnings.length > 0 ? warnings.join('\n') : 'Inventory updated successfully'
                };
            }
            catch (error) {
                const err = error;
                winston_middleware_1.logger.error('Error updating inventory from prep item:', { error: err.message, stack: err.stack });
                return { success: false, message: `Failed to update inventory: ${err.message}` };
            }
        });
    }
    static getOutOfStockItems(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const outOfStockItems = yield connection_1.db.select({
                    ingredientId: schema_1.dimIngredient.ingredientId,
                    ingredientName: schema_1.dimIngredient.ingredientName,
                    quantity: schema_1.factInventory.quantity,
                    quantityThreshold: schema_1.dimIngredient.reorderPoint,
                    unit: schema_1.dimIngredient.unit,
                    maxStock: schema_1.dimIngredient.parLevel,
                    lastUpdated: schema_1.dimIngredient.updatedAt
                })
                    .from(schema_1.dimIngredient)
                    .leftJoin(schema_1.factInventory, (0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, schema_1.factInventory.ingredientId))
                    .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factInventory.quantity, "0")));
                return outOfStockItems;
            }
            catch (error) {
                console.error('Error fetching out of stock items:', error);
                throw new Error('Failed to fetch out of stock items');
            }
        });
    }
}
exports.IngredientService = IngredientService;
