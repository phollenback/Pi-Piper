"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateRestaurantMetrics = exports.updateAllRestaurantMetrics = void 0;
const connection_1 = require("../db/connection");
const drizzle_orm_1 = require("drizzle-orm");
const schema_1 = require("../db/schema");
const winston_middleware_1 = require("../middleware/winston.middleware");
const date_fns_1 = require("date-fns");
/**
 * Calculate and update metrics for all restaurants
 */
const updateAllRestaurantMetrics = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        winston_middleware_1.logger.info('[metrics.service][updateAllRestaurantMetrics][START]');
        // Get all active restaurants
        const restaurants = yield connection_1.db.select({
            restaurantId: schema_1.dimRestaurant.restaurantId,
            restaurantName: schema_1.dimRestaurant.restaurantName
        })
            .from(schema_1.dimRestaurant)
            .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurant.isActive, true));
        // Calculate metrics for each restaurant
        for (const restaurant of restaurants) {
            try {
                yield (0, exports.updateRestaurantMetrics)(restaurant.restaurantId);
                winston_middleware_1.logger.info(`[metrics.service][updateAllRestaurantMetrics] Updated metrics for restaurant ${restaurant.restaurantId} (${restaurant.restaurantName})`);
            }
            catch (error) {
                winston_middleware_1.logger.error(`[metrics.service][updateAllRestaurantMetrics] Error updating metrics for restaurant ${restaurant.restaurantId}:`, error);
            }
        }
        winston_middleware_1.logger.info('[metrics.service][updateAllRestaurantMetrics][SUCCESS]');
    }
    catch (error) {
        winston_middleware_1.logger.error('[metrics.service][updateAllRestaurantMetrics][ERROR]', error);
        throw error;
    }
});
exports.updateAllRestaurantMetrics = updateAllRestaurantMetrics;
/**
 * Calculate and update metrics for a specific restaurant
 */
const updateRestaurantMetrics = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        winston_middleware_1.logger.info(`[metrics.service][updateRestaurantMetrics][START] restaurantId: ${restaurantId}`);
        const today = new Date();
        const dateStr = (0, date_fns_1.format)(today, 'yyyy-MM-dd');
        // Calculate inventory turnover
        const inventoryTurnover = yield calculateInventoryTurnover(restaurantId);
        // Calculate average prep time
        const avgPrepTime = yield calculateAveragePrepTime(restaurantId);
        // Calculate average ingredient price
        const avgIngredientPrice = yield calculateAverageIngredientPrice(restaurantId);
        // Calculate cleaning completion percentages
        const monthlyCleaningPct = yield calculateCleaningCompletionPercentage(restaurantId, 'monthly');
        const weeklyCleaningPct = yield calculateCleaningCompletionPercentage(restaurantId, 'weekly');
        // Use raw SQL to insert or update metrics
        yield connection_1.db.execute((0, drizzle_orm_1.sql) `
      INSERT INTO fact_restaurant_metrics (
        restaurant_id, 
        date, 
        inventory_turnover, 
        avg_prep_time_hours, 
        overall_ingredient_price_avg, 
        monthly_cleaning_completion_pct, 
        weekly_cleaning_completion_pct
      ) 
      VALUES (
        ${restaurantId}, 
        ${dateStr}, 
        ${inventoryTurnover}, 
        ${avgPrepTime}, 
        ${avgIngredientPrice}, 
        ${monthlyCleaningPct}, 
        ${weeklyCleaningPct}
      )
      ON DUPLICATE KEY UPDATE
        inventory_turnover = ${inventoryTurnover},
        avg_prep_time_hours = ${avgPrepTime},
        overall_ingredient_price_avg = ${avgIngredientPrice},
        monthly_cleaning_completion_pct = ${monthlyCleaningPct},
        weekly_cleaning_completion_pct = ${weeklyCleaningPct},
        updated_at = CURRENT_TIMESTAMP
    `);
        winston_middleware_1.logger.info(`[metrics.service][updateRestaurantMetrics][SUCCESS] restaurantId: ${restaurantId}`);
    }
    catch (error) {
        winston_middleware_1.logger.error(`[metrics.service][updateRestaurantMetrics][ERROR] restaurantId: ${restaurantId}`, error);
        throw error;
    }
});
exports.updateRestaurantMetrics = updateRestaurantMetrics;
/**
 * Calculate inventory turnover (turns/month)
 * Measures how many times the entire inventory is replenished per month
 */
const calculateInventoryTurnover = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        winston_middleware_1.logger.info(`[metrics.service][calculateInventoryTurnover][START] restaurantId: ${restaurantId}`);
        const oneMonthAgo = (0, date_fns_1.subMonths)(new Date(), 1);
        const today = new Date();
        const oneMonthAgoDateId = parseInt((0, date_fns_1.format)(oneMonthAgo, 'yyyyMMdd'));
        const todayDateId = parseInt((0, date_fns_1.format)(today, 'yyyyMMdd'));
        // Get all active ingredients for this restaurant
        const ingredients = yield connection_1.db.select({
            ingredientId: schema_1.dimIngredient.ingredientId,
            ingredientName: schema_1.dimIngredient.ingredientName
        })
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.isActive, true)));
        if (ingredients.length === 0) {
            winston_middleware_1.logger.info(`[metrics.service][calculateInventoryTurnover] No active ingredients found for restaurant ${restaurantId}`);
            return null;
        }
        winston_middleware_1.logger.info(`[metrics.service][calculateInventoryTurnover] Found ${ingredients.length} active ingredients for restaurant ${restaurantId}`);
        // For each ingredient, count replenishment events from the transaction table
        let totalReplenishmentCount = 0;
        for (const ingredient of ingredients) {
            // Get replenishment transactions (where quantityChange > 0 and transactionType = 'order')
            const replenishmentTransactions = yield connection_1.db.select({
                transactionId: schema_1.factInventoryTransaction.transactionId,
                quantityChange: schema_1.factInventoryTransaction.quantityChange,
                dateId: schema_1.factInventoryTransaction.dateId
            })
                .from(schema_1.factInventoryTransaction)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, ingredient.ingredientId), (0, drizzle_orm_1.gte)(schema_1.factInventoryTransaction.dateId, oneMonthAgoDateId), (0, drizzle_orm_1.lt)(schema_1.factInventoryTransaction.dateId, todayDateId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.transactionType, 'order'), (0, drizzle_orm_1.sql) `quantity_change > 0`));
            const replenishmentCount = replenishmentTransactions.length;
            totalReplenishmentCount += replenishmentCount;
            winston_middleware_1.logger.info(`[metrics.service][calculateInventoryTurnover] Ingredient ${ingredient.ingredientName} was replenished ${replenishmentCount} times in the last month`);
        }
        // Calculate average replenishment count per ingredient
        const avgReplenishmentPerIngredient = totalReplenishmentCount / ingredients.length;
        winston_middleware_1.logger.info(`[metrics.service][calculateInventoryTurnover] Total replenishments: ${totalReplenishmentCount}, Average per ingredient: ${avgReplenishmentPerIngredient}`);
        return parseFloat(avgReplenishmentPerIngredient.toFixed(2));
    }
    catch (error) {
        winston_middleware_1.logger.error(`[metrics.service][calculateInventoryTurnover][ERROR] restaurantId: ${restaurantId}`, error);
        return null;
    }
});
/**
 * Calculate average prep time in hours
 * Measures from 6 AM until the last completed item for each day, then averages
 */
const calculateAveragePrepTime = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const oneMonthAgo = (0, date_fns_1.subMonths)(new Date(), 1);
        const today = new Date();
        const oneMonthAgoDateId = parseInt((0, date_fns_1.format)(oneMonthAgo, 'yyyyMMdd'));
        const todayDateId = parseInt((0, date_fns_1.format)(today, 'yyyyMMdd'));
        winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime][START] restaurantId: ${restaurantId}, date range: ${oneMonthAgoDateId} to ${todayDateId}`);
        // Get completion records from the fact_prep_completion table
        const completionRecords = yield connection_1.db.select({
            dateId: schema_1.factPrepCompletion.dateId,
            completionTime: schema_1.factPrepCompletion.completionTime
        })
            .from(schema_1.factPrepCompletion)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factPrepCompletion.restaurantId, restaurantId), (0, drizzle_orm_1.gte)(schema_1.factPrepCompletion.dateId, oneMonthAgoDateId), (0, drizzle_orm_1.lt)(schema_1.factPrepCompletion.dateId, todayDateId)));
        winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Found ${completionRecords.length} completion records for restaurant ${restaurantId}`);
        if (completionRecords.length === 0) {
            winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] No completion records found for restaurant ${restaurantId}`);
            return null;
        }
        // Group completion times by date_id to find the latest completion time for each day
        const dateCompletionMap = new Map();
        for (const record of completionRecords) {
            const dateId = record.dateId;
            const completionTime = new Date(record.completionTime);
            if (!dateCompletionMap.has(dateId) || completionTime > dateCompletionMap.get(dateId)) {
                dateCompletionMap.set(dateId, completionTime);
                winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Set/updated completion time for date ${dateId}: ${completionTime.toISOString()}`);
            }
        }
        // Calculate hours from 6 AM to last completion for each day
        let totalHours = 0;
        let daysCount = 0;
        for (const [dateId, completionTime] of dateCompletionMap.entries()) {
            // Extract date components from dateId
            const dateStr = dateId.toString();
            const year = parseInt(dateStr.substring(0, 4));
            const month = parseInt(dateStr.substring(4, 6)) - 1; // JS months are 0-indexed
            const day = parseInt(dateStr.substring(6, 8));
            // Create a date object for this day at midnight in local time
            const dateAtMidnight = new Date(year, month, day, 0, 0, 0);
            // Create 6 AM time for this date in the local timezone
            const sixAM = new Date(dateAtMidnight);
            sixAM.setHours(6, 0, 0, 0);
            winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Date ${dateId}: Date at midnight = ${dateAtMidnight.toISOString()}`);
            winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Date ${dateId}: 6 AM time = ${sixAM.toISOString()}, completion time = ${completionTime.toISOString()}`);
            // Calculate hours difference
            const diffMs = completionTime.getTime() - sixAM.getTime();
            const diffHours = diffMs / (1000 * 60 * 60);
            winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Date ${dateId}: Hours difference = ${diffHours}`);
            // Only count positive differences (completions after 6 AM)
            if (diffHours > 0) {
                totalHours += diffHours;
                daysCount++;
                winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Date ${dateId}: Added ${diffHours} hours to total`);
            }
            else {
                winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Date ${dateId}: Skipped negative hours difference: ${diffHours}`);
            }
        }
        if (daysCount === 0) {
            winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] No valid completion records found for restaurant ${restaurantId}`);
            return null;
        }
        // Calculate average hours
        const avgHours = totalHours / daysCount;
        winston_middleware_1.logger.info(`[metrics.service][calculateAveragePrepTime] Final calculation: Average hours = ${avgHours} (total: ${totalHours}, days: ${daysCount})`);
        return parseFloat(avgHours.toFixed(2));
    }
    catch (error) {
        winston_middleware_1.logger.error(`[metrics.service][calculateAveragePrepTime][ERROR] restaurantId: ${restaurantId}`, error);
        return null;
    }
});
/**
 * Calculate average ingredient price
 */
const calculateAverageIngredientPrice = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Get average price of all ingredients for the restaurant
        const result = yield connection_1.db.select({
            avgPrice: (0, drizzle_orm_1.avg)(schema_1.factInventory.unitPrice)
        })
            .from(schema_1.factInventory)
            .innerJoin(schema_1.dimIngredient, (0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, schema_1.dimIngredient.ingredientId))
            .where((0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId));
        if (!result[0].avgPrice)
            return null;
        const avgPrice = Number(result[0].avgPrice);
        return parseFloat(avgPrice.toFixed(2));
    }
    catch (error) {
        winston_middleware_1.logger.error(`[metrics.service][calculateAverageIngredientPrice][ERROR] restaurantId: ${restaurantId}`, error);
        return null;
    }
});
/**
 * Calculate cleaning completion percentage
 */
const calculateCleaningCompletionPercentage = (restaurantId, frequency) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        // Determine date range based on frequency
        const today = new Date();
        let startDate;
        if (frequency === 'weekly') {
            startDate = (0, date_fns_1.subWeeks)(today, 1);
        }
        else if (frequency === 'monthly') {
            startDate = (0, date_fns_1.subMonths)(today, 1);
        }
        else {
            return null;
        }
        // Get all cleaning tasks of the specified frequency
        const tasks = yield connection_1.db.select({
            taskId: schema_1.dimCleaningTask.taskId
        })
            .from(schema_1.dimCleaningTask)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimCleaningTask.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.dimCleaningTask.frequency, frequency)));
        if (tasks.length === 0)
            return null;
        // Get completion status for these tasks
        const completions = yield connection_1.db.select({
            completed: schema_1.factCleaningCompletion.completed
        })
            .from(schema_1.factCleaningCompletion)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factCleaningCompletion.restaurantId, restaurantId), (0, drizzle_orm_1.gte)(schema_1.factCleaningCompletion.date, startDate), (0, drizzle_orm_1.lt)(schema_1.factCleaningCompletion.date, today)));
        if (completions.length === 0)
            return null;
        // Calculate completion percentage
        const completedCount = completions.filter(c => c.completed).length;
        const percentage = (completedCount / completions.length) * 100;
        return parseFloat(percentage.toFixed(2));
    }
    catch (error) {
        winston_middleware_1.logger.error(`[metrics.service][calculateCleaningCompletionPercentage][ERROR] restaurantId: ${restaurantId}, frequency: ${frequency}`, error);
        return null;
    }
});
