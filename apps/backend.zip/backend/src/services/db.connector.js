"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = exports.initializeDbConnector = exports.execute = void 0;
const promise_1 = __importDefault(require("mysql2/promise"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const pool = promise_1.default.createPool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: parseInt(process.env.DB_PORT || '3306'),
});
exports.pool = pool;
const execute = (query, params) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const [rows] = yield pool.query(query, params);
        return rows;
    }
    catch (error) {
        winston_middleware_1.logger.error('[db.connector][execute][ERROR]', { error });
        throw error;
    }
});
exports.execute = execute;
const initializeDbConnector = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield pool.getConnection();
        winston_middleware_1.logger.info('[db.connector][initialize][SUCCESS] Database connected');
    }
    catch (error) {
        winston_middleware_1.logger.error('[db.connector][initialize][ERROR]', { error });
        throw error;
    }
});
exports.initializeDbConnector = initializeDbConnector;
