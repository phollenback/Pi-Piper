"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestaurantSettingsService = void 0;
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const winston_middleware_1 = require("../middleware/winston.middleware");
/**
 * Service for managing restaurant settings
 */
class RestaurantSettingsService {
    /**
     * Get settings for a restaurant
     * @param restaurantId - The restaurant ID
     * @returns The restaurant settings or null if not found
     */
    static getSettings(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                winston_middleware_1.logger.info('[restaurant-settings.service][getSettings][START]', { restaurantId });
                const settings = yield connection_1.db.select()
                    .from(schema_1.dimRestaurantSettings)
                    .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurantSettings.restaurantId, restaurantId))
                    .limit(1);
                if (settings.length === 0) {
                    // Create default settings if none exist
                    const newSettings = yield this.createDefaultSettings(restaurantId);
                    winston_middleware_1.logger.info('[restaurant-settings.service][getSettings][DEFAULT_CREATED]', { restaurantId, settings: newSettings });
                    return newSettings;
                }
                winston_middleware_1.logger.info('[restaurant-settings.service][getSettings][SUCCESS]', { restaurantId, settings: settings[0] });
                return settings[0];
            }
            catch (error) {
                winston_middleware_1.logger.error('[restaurant-settings.service][getSettings][ERROR]', { restaurantId, error });
                throw error;
            }
        });
    }
    /**
     * Update the low stock threshold for a restaurant
     * @param restaurantId - The restaurant ID
     * @param threshold - The new threshold percentage (0-100)
     * @returns The updated settings
     */
    static updateLowStockThreshold(restaurantId, threshold) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                winston_middleware_1.logger.info('[restaurant-settings.service][updateLowStockThreshold][START]', { restaurantId, threshold });
                // Ensure threshold is within valid range
                const validThreshold = Math.max(0, Math.min(100, threshold));
                // Check if settings exist
                const existingSettings = yield connection_1.db.select()
                    .from(schema_1.dimRestaurantSettings)
                    .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurantSettings.restaurantId, restaurantId))
                    .limit(1);
                if (existingSettings.length === 0) {
                    // Create new settings
                    yield connection_1.db.insert(schema_1.dimRestaurantSettings)
                        .values({
                        restaurantId,
                        lowStockThreshold: validThreshold
                    });
                    winston_middleware_1.logger.info('[restaurant-settings.service][updateLowStockThreshold][CREATED]', { restaurantId, threshold: validThreshold });
                }
                else {
                    // Update existing settings
                    yield connection_1.db.update(schema_1.dimRestaurantSettings)
                        .set({ lowStockThreshold: validThreshold })
                        .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurantSettings.restaurantId, restaurantId));
                    winston_middleware_1.logger.info('[restaurant-settings.service][updateLowStockThreshold][UPDATED]', { restaurantId, threshold: validThreshold });
                }
                // Fetch and return the updated settings
                const updatedSettings = yield connection_1.db.select()
                    .from(schema_1.dimRestaurantSettings)
                    .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurantSettings.restaurantId, restaurantId))
                    .limit(1);
                return updatedSettings.length > 0 ? updatedSettings[0] : null;
            }
            catch (error) {
                winston_middleware_1.logger.error('[restaurant-settings.service][updateLowStockThreshold][ERROR]', { restaurantId, threshold, error });
                throw error;
            }
        });
    }
    /**
     * Create default settings for a restaurant
     * @param restaurantId - The restaurant ID
     * @returns The created settings
     */
    static createDefaultSettings(restaurantId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield connection_1.db.insert(schema_1.dimRestaurantSettings)
                    .values({
                    restaurantId,
                    lowStockThreshold: 40 // Default 40%
                });
                // Fetch the newly created settings
                const settings = yield connection_1.db.select()
                    .from(schema_1.dimRestaurantSettings)
                    .where((0, drizzle_orm_1.eq)(schema_1.dimRestaurantSettings.restaurantId, restaurantId))
                    .limit(1);
                return settings.length > 0 ? settings[0] : null;
            }
            catch (error) {
                winston_middleware_1.logger.error('[restaurant-settings.service][createDefaultSettings][ERROR]', { restaurantId, error });
                throw error;
            }
        });
    }
}
exports.RestaurantSettingsService = RestaurantSettingsService;
