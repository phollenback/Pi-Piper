"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestaurantSettingsController = void 0;
const restaurant_settings_service_1 = require("../services/restaurant-settings.service");
const winston_middleware_1 = require("../middleware/winston.middleware");
class RestaurantSettingsController {
    /**
     * Get settings for a restaurant
     */
    static getSettings(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const restaurantId = parseInt(req.params.restaurantId);
                if (isNaN(restaurantId)) {
                    return res.status(400).json({ message: 'Invalid restaurant ID' });
                }
                const settings = yield restaurant_settings_service_1.RestaurantSettingsService.getSettings(restaurantId);
                if (!settings) {
                    return res.status(404).json({ message: 'Settings not found' });
                }
                return res.status(200).json(settings);
            }
            catch (error) {
                winston_middleware_1.logger.error('[restaurant-settings.controller][getSettings][ERROR]', { error });
                return res.status(500).json({ message: 'Failed to retrieve restaurant settings', error });
            }
        });
    }
    /**
     * Update the low stock threshold for a restaurant
     */
    static updateLowStockThreshold(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const restaurantId = parseInt(req.params.restaurantId);
                const { threshold } = req.body;
                if (isNaN(restaurantId)) {
                    return res.status(400).json({ message: 'Invalid restaurant ID' });
                }
                if (threshold === undefined || isNaN(threshold) || threshold < 0 || threshold > 100) {
                    return res.status(400).json({ message: 'Invalid threshold value. Must be a number between 0 and 100.' });
                }
                const settings = yield restaurant_settings_service_1.RestaurantSettingsService.updateLowStockThreshold(restaurantId, threshold);
                if (!settings) {
                    return res.status(404).json({ message: 'Failed to update settings' });
                }
                return res.status(200).json({
                    message: 'Low stock threshold updated successfully',
                    settings
                });
            }
            catch (error) {
                winston_middleware_1.logger.error('[restaurant-settings.controller][updateLowStockThreshold][ERROR]', { error });
                return res.status(500).json({ message: 'Failed to update low stock threshold', error });
            }
        });
    }
}
exports.RestaurantSettingsController = RestaurantSettingsController;
