"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const ingredient_service_1 = require("../services/ingredient.service");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
/**
 * Script to test the inventory tracking functionality
 * This script will:
 * 1. Create a test ingredient and prep item
 * 2. Test normal inventory update
 * 3. Test inventory going below zero
 * 4. Test inventory reaching zero exactly
 * 5. Test inventory running low
 * 6. Clean up test data
 */
function testInventoryTracking() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Starting inventory tracking tests...');
        // Test data
        const testRestaurantId = 999;
        const testIngredientId = 9999;
        const testPrepItemId = 9999;
        const testIngredientName = 'Test Ingredient';
        const testPrepItemName = 'Test Prep Item';
        try {
            // Step 1: Create test data
            console.log('\n1. Setting up test data...');
            // Check if test data already exists and clean it up
            yield cleanupTestData(testIngredientId, testPrepItemId, testRestaurantId);
            // Create test ingredient
            yield connection_1.db.insert(schema_1.dimIngredient).values({
                ingredientId: testIngredientId,
                ingredientName: testIngredientName,
                restaurantId: testRestaurantId,
                unit: 'units',
                unitPrice: '1.00',
                parLevel: '10',
                currentStock: '10',
                reorderPoint: '2',
                isActive: true
            });
            console.log('- Created test ingredient');
            // Create test prep item
            yield connection_1.db.insert(schema_1.dimPrepItem).values({
                prepItemId: testPrepItemId,
                name: testPrepItemName,
                restaurantId: testRestaurantId,
                kitchenDepartmentId: 1
            });
            console.log('- Created test prep item');
            // Create test inventory record
            yield connection_1.db.insert(schema_1.factInventory).values({
                ingredientId: testIngredientId,
                restaurantId: testRestaurantId,
                dateId: parseInt(new Date().toISOString().split('T')[0].replace(/-/g, '')),
                quantity: '10',
                unit: 'units'
            });
            console.log('- Created test inventory record');
            // Create test prep item ingredient relationship
            yield connection_1.db.insert(schema_1.factPrepItemIngredients).values({
                prepItemId: testPrepItemId,
                ingredientId: testIngredientId,
                quantity: '5',
                unit: 'units'
            });
            console.log('- Created test prep item ingredient relationship');
            // Step 2: Test normal inventory update
            console.log('\n2. Testing normal inventory update...');
            yield resetInventory(testIngredientId, testRestaurantId, '10');
            const normalResult = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
            console.log('- Result:', normalResult);
            const normalInventory = yield getInventoryQuantity(testIngredientId, testRestaurantId);
            console.log('- Updated inventory quantity:', normalInventory);
            const normalTransactions = yield getLatestTransaction(testIngredientId, testRestaurantId);
            console.log('- Transaction recorded:', normalTransactions);
            // Step 3: Test inventory going below zero
            console.log('\n3. Testing inventory going below zero...');
            yield resetInventory(testIngredientId, testRestaurantId, '3');
            yield updatePrepItemQuantity(testPrepItemId, testIngredientId, '5');
            const belowZeroResult = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
            console.log('- Result:', belowZeroResult);
            const belowZeroInventory = yield getInventoryQuantity(testIngredientId, testRestaurantId);
            console.log('- Updated inventory quantity:', belowZeroInventory);
            const belowZeroTransactions = yield getLatestTransaction(testIngredientId, testRestaurantId);
            console.log('- Transaction recorded:', belowZeroTransactions);
            // Step 4: Test inventory reaching zero exactly
            console.log('\n4. Testing inventory reaching zero exactly...');
            yield resetInventory(testIngredientId, testRestaurantId, '5');
            yield updatePrepItemQuantity(testPrepItemId, testIngredientId, '5');
            const zeroResult = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
            console.log('- Result:', zeroResult);
            const zeroInventory = yield getInventoryQuantity(testIngredientId, testRestaurantId);
            console.log('- Updated inventory quantity:', zeroInventory);
            const zeroTransactions = yield getLatestTransaction(testIngredientId, testRestaurantId);
            console.log('- Transaction recorded:', zeroTransactions);
            // Step 5: Test inventory running low
            console.log('\n5. Testing inventory running low...');
            yield resetInventory(testIngredientId, testRestaurantId, '7');
            yield updatePrepItemQuantity(testPrepItemId, testIngredientId, '5');
            const lowResult = yield ingredient_service_1.IngredientService.updateInventoryFromPrepItem(testPrepItemId, testRestaurantId, 'complete');
            console.log('- Result:', lowResult);
            const lowInventory = yield getInventoryQuantity(testIngredientId, testRestaurantId);
            console.log('- Updated inventory quantity:', lowInventory);
            const lowTransactions = yield getLatestTransaction(testIngredientId, testRestaurantId);
            console.log('- Transaction recorded:', lowTransactions);
            // Step 6: Clean up test data
            console.log('\n6. Cleaning up test data...');
            yield cleanupTestData(testIngredientId, testPrepItemId, testRestaurantId);
            console.log('- Test data cleaned up');
            console.log('\nInventory tracking tests completed successfully!');
        }
        catch (error) {
            console.error('Error during inventory tracking tests:', error);
        }
        finally {
            process.exit(0);
        }
    });
}
// Helper functions
function cleanupTestData(ingredientId, prepItemId, restaurantId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Delete test data
            yield connection_1.db.delete(schema_1.factInventoryTransaction)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, restaurantId)));
            yield connection_1.db.delete(schema_1.factPrepItemIngredients)
                .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
            yield connection_1.db.delete(schema_1.factInventory)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
            yield connection_1.db.delete(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId));
            yield connection_1.db.delete(schema_1.dimIngredient)
                .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId));
        }
        catch (error) {
            console.error('Error cleaning up test data:', error);
        }
    });
}
function resetInventory(ingredientId, restaurantId, quantity) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield connection_1.db.update(schema_1.factInventory)
                .set({ quantity: (0, drizzle_orm_1.sql) `${quantity}` })
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
        }
        catch (error) {
            console.error('Error resetting inventory quantity:', error);
        }
    });
}
function updatePrepItemQuantity(prepItemId, ingredientId, quantity) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield connection_1.db.update(schema_1.factPrepItemIngredients)
                .set({ quantity: (0, drizzle_orm_1.sql) `${quantity}` })
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.ingredientId, ingredientId)));
        }
        catch (error) {
            console.error('Error updating prep item quantity:', error);
        }
    });
}
function getInventoryQuantity(ingredientId, restaurantId) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        try {
            const inventory = yield connection_1.db.select({ quantity: schema_1.factInventory.quantity })
                .from(schema_1.factInventory)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventory.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventory.restaurantId, restaurantId)));
            return (_a = inventory[0]) === null || _a === void 0 ? void 0 : _a.quantity;
        }
        catch (error) {
            console.error('Error getting inventory quantity:', error);
            return null;
        }
    });
}
function getLatestTransaction(ingredientId, restaurantId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const transactions = yield connection_1.db.select()
                .from(schema_1.factInventoryTransaction)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.factInventoryTransaction.restaurantId, restaurantId)))
                .orderBy(schema_1.factInventoryTransaction.transactionId)
                .limit(1);
            return transactions[0];
        }
        catch (error) {
            console.error('Error getting latest transaction:', error);
            return null;
        }
    });
}
// Run the script
testInventoryTracking();
