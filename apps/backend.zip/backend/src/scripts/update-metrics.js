#!/usr/bin/env node
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const metrics_service_1 = require("../services/metrics.service");
const winston_middleware_1 = require("../middleware/winston.middleware");
/**
 * Script to update metrics for all restaurants
 * This script is designed to be run daily at 2 AM via a cron job
 *
 * Example cron entry:
 * 0 2 * * * /path/to/node /path/to/backend/dist/scripts/update-metrics.js >> /path/to/logs/metrics-update.log 2>&1
 */
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            winston_middleware_1.logger.info('[update-metrics] Starting metrics update process');
            // Update metrics for all restaurants
            yield (0, metrics_service_1.updateAllRestaurantMetrics)();
            winston_middleware_1.logger.info('[update-metrics] Metrics update completed successfully');
            process.exit(0);
        }
        catch (error) {
            winston_middleware_1.logger.error('[update-metrics] Error updating metrics:', error);
            process.exit(1);
        }
    });
}
// Run the script
main();
