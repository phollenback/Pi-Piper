"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const date_fns_1 = require("date-fns");
/**
 * Script to generate mock historical inventory data
 * This will create realistic inventory transactions over the past 30 days
 */
function generateInventoryHistory() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log('Starting to generate mock inventory history...');
            // Get all active ingredients
            const ingredients = yield connection_1.db.select({
                ingredientId: schema_1.dimIngredient.ingredientId,
                ingredientName: schema_1.dimIngredient.ingredientName,
                restaurantId: schema_1.dimIngredient.restaurantId,
                currentStock: schema_1.dimIngredient.currentStock,
                parLevel: schema_1.dimIngredient.parLevel
            })
                .from(schema_1.dimIngredient)
                .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.isActive, true));
            console.log(`Found ${ingredients.length} active ingredients`);
            // For each ingredient, generate a series of transactions over the past 30 days
            for (const ingredient of ingredients) {
                console.log(`Generating history for ${ingredient.ingredientName} (ID: ${ingredient.ingredientId})`);
                // Start with the current stock as the end point
                let currentQuantity = Number(ingredient.currentStock) || 0;
                const parLevel = Number(ingredient.parLevel) || 20; // Default par level if not set
                // Generate transactions for the past 30 days
                for (let i = 0; i < 30; i++) {
                    const date = (0, date_fns_1.subDays)(new Date(), i);
                    const dateId = parseInt((0, date_fns_1.format)(date, 'yyyyMMdd'));
                    // Randomly decide if there was usage on this day (70% chance)
                    if (Math.random() < 0.7) {
                        // Usage amount is between 5% and 25% of par level
                        const usageAmount = -(Math.random() * 0.2 + 0.05) * parLevel;
                        const roundedUsage = Math.round(usageAmount * 100) / 100; // Round to 2 decimal places
                        const previousQuantity = currentQuantity;
                        currentQuantity += roundedUsage;
                        // If stock would go below zero, adjust it
                        if (currentQuantity < 0) {
                            currentQuantity = 0;
                        }
                        // Create a usage transaction
                        yield connection_1.db.insert(schema_1.factInventoryTransaction).values({
                            ingredientId: ingredient.ingredientId,
                            restaurantId: ingredient.restaurantId,
                            dateId: dateId,
                            quantityChange: String(roundedUsage),
                            transactionType: 'usage',
                            referenceId: null,
                            previousQuantity: String(previousQuantity),
                            newQuantity: String(currentQuantity),
                            notes: 'Daily usage',
                            createdBy: null,
                            createdAt: new Date()
                        });
                        console.log(`Created usage transaction: ${roundedUsage} on ${(0, date_fns_1.format)(date, 'yyyy-MM-dd')}`);
                        // If stock is below 20% of par level, create a replenishment transaction (80% chance)
                        if (currentQuantity < parLevel * 0.2 && Math.random() < 0.8) {
                            // Replenishment brings stock back to 80-100% of par level
                            const replenishmentFactor = Math.random() * 0.2 + 0.8; // 0.8 to 1.0
                            const replenishmentAmount = (parLevel * replenishmentFactor) - currentQuantity;
                            const roundedReplenishment = Math.round(replenishmentAmount * 100) / 100;
                            const previousQuantityAfterUsage = currentQuantity;
                            currentQuantity += roundedReplenishment;
                            // Create a replenishment transaction
                            yield connection_1.db.insert(schema_1.factInventoryTransaction).values({
                                ingredientId: ingredient.ingredientId,
                                restaurantId: ingredient.restaurantId,
                                dateId: dateId,
                                quantityChange: String(roundedReplenishment),
                                transactionType: 'order',
                                referenceId: null,
                                previousQuantity: String(previousQuantityAfterUsage),
                                newQuantity: String(currentQuantity),
                                notes: 'Inventory replenishment',
                                createdBy: null,
                                createdAt: new Date(date.setHours(date.getHours() + 2)) // 2 hours after usage
                            });
                            console.log(`Created replenishment transaction: +${roundedReplenishment} on ${(0, date_fns_1.format)(date, 'yyyy-MM-dd')}`);
                        }
                    }
                }
            }
            console.log('Mock inventory history generation completed successfully!');
        }
        catch (error) {
            console.error('Error generating mock inventory history:', error);
        }
        finally {
            process.exit(0);
        }
    });
}
// Run the script
generateInventoryHistory();
