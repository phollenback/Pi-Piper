"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const PrepItemController = __importStar(require("./prepitem.controller"));
const prepitem_model_1 = require("./prepitem.model");
const asyncHandler_1 = __importDefault(require("../util/asyncHandler"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const { checkSchema } = require('express-validator');
const router = (0, express_1.Router)();
router.use(winston_middleware_1.responseTimeLogger);
router.use(winston_middleware_1.requestLogger);
router
    // fetch daily prep items for a restaurant (more specific route first)
    .get('/daily/:restaurantId', (0, asyncHandler_1.default)(PrepItemController.readDailyPrepItems))
    // update daily prep items for a restaurant
    .put('/daily/:restaurantId', checkSchema(prepitem_model_1.PrepListItemSchema), (0, asyncHandler_1.default)(PrepItemController.updateDailyPrepItem))
    // create daily prep items for a restaurant
    .post('/daily/:restaurantId', (0, asyncHandler_1.default)(PrepItemController.createDailyPrepItems))
    // fetch all prep items for a restaurant (general route after specific routes)
    .get('/:restaurantId', (0, asyncHandler_1.default)(PrepItemController.readPrepItems))
    // create a new prep item
    .post('/:restaurantId', checkSchema(prepitem_model_1.PrepItemSchema), (0, asyncHandler_1.default)(PrepItemController.createPrepItem))
    // update an existing prep item
    .put('/:restaurantId/:prepItemId', checkSchema(prepitem_model_1.PrepItemSchema), (0, asyncHandler_1.default)(PrepItemController.updatePrepItem));
exports.default = router;
