"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrepItemSchema = exports.PrepListItemSchema = void 0;
const { Schema } = require('express-validator');
exports.PrepListItemSchema = {
    name: {
        notEmpty: true,
        errorMessage: 'Prep List Item Name field cannot be empty.'
    },
    description: {
        notEmpty: false, // Can be empty, but if it's filled, no validation is required
        errorMessage: 'Description field cannot be empty.'
    },
    note: {
        notEmpty: false, // Can be empty
        errorMessage: 'Note field cannot be empty.'
    },
    quantity: {
        notEmpty: true,
        isInt: {
            options: { min: 0 },
            errorMessage: 'Quantity must be a positive integer.'
        },
        errorMessage: 'Quantity field cannot be empty.'
    },
    unit: {
        notEmpty: true,
        errorMessage: 'Unit field cannot be empty.'
    },
    status: {
        notEmpty: true,
        isIn: {
            options: ['complete', 'todo', 'in-progress'],
            errorMessage: 'Status must be one of: complete, todo, or in-progress.'
        },
        errorMessage: 'Status field cannot be empty.'
    },
    category: {
        notEmpty: true,
        isInt: true,
        errorMessage: 'Category field must be a valid integer.'
    },
    restaurant_id: {
        notEmpty: true,
        isInt: true,
        errorMessage: 'Restaurant ID field must be a valid integer.'
    }
};
exports.PrepItemSchema = {
    prep_item_name: {
        notEmpty: true,
        errorMessage: 'Prep Item Name field cannot be empty.'
    },
    description: {
        notEmpty: false,
        errorMessage: 'Description field cannot be empty.'
    },
    category: {
        notEmpty: true,
        isInt: true,
        errorMessage: 'Category field cannot be empty.'
    },
    kitchen_department_id: {
        notEmpty: true,
        isInt: true,
        errorMessage: 'Kitchen Department field cannot be empty.'
    }
};
