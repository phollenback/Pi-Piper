"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const prepitems_routes_1 = __importDefault(require("./prepitems.routes"));
const PrepItemController = __importStar(require("./prepitem.controller"));
// Mock the prepitem controller
jest.mock('./prepitem.controller', () => ({
    readPrepItems: jest.fn(),
    readDailyPrepItems: jest.fn(),
    updateDailyPrepItem: jest.fn(),
    createDailyPrepItems: jest.fn(),
    createPrepItem: jest.fn()
}));
// Mock express-validator
jest.mock('express-validator', () => ({
    checkSchema: () => [(_req, _res, next) => next()],
    validationResult: jest.fn(() => ({ isEmpty: () => true }))
}));
// Mock the database connection
jest.mock('../services/pg.connector', () => ({
    pool: {
        end: jest.fn()
    }
}));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use('/prepitems', prepitems_routes_1.default);
describe('PrepItem API', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('GET /prepitems/:restaurantId', () => {
        it('should return prep items for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockPrepItems = [
                { prep_item_id: 1, name: 'Slice Prosciutto', description: 'Thinly slice prosciutto', category: 1 },
                { prep_item_id: 2, name: 'Chop Carrots', description: 'Dice carrots into small cubes', category: 2 }
            ];
            // Mock the readPrepItems function
            jest.mocked(PrepItemController.readPrepItems).mockImplementation((req, res) => {
                res.status(200).json(mockPrepItems);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/prepitems/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockPrepItems);
            expect(PrepItemController.readPrepItems).toHaveBeenCalled();
        }));
        it('should handle errors when fetching prep items', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the readPrepItems function to simulate an error
            jest.mocked(PrepItemController.readPrepItems).mockImplementation((req, res) => {
                res.status(500).json({ error: 'Failed to fetch prep items' });
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/prepitems/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ error: 'Failed to fetch prep items' });
        }));
    });
    describe('GET /prepitems/daily/:restaurantId', () => {
        it('should return daily prep items for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockDailyPrepItems = [
                { prep_list_id: 1, name: 'Slice Prosciutto', description: 'Thinly slice prosciutto', category: 1, status: 'todo' },
                { prep_list_id: 2, name: 'Chop Carrots', description: 'Dice carrots into small cubes', category: 2, status: 'in-progress' }
            ];
            // Mock the readDailyPrepItems function
            jest.mocked(PrepItemController.readDailyPrepItems).mockImplementation((req, res) => {
                return Promise.resolve(res.status(200).json([]));
            });
            const response = yield (0, supertest_1.default)(app).get('/prepitems/daily/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual([]);
            expect(PrepItemController.readDailyPrepItems).toHaveBeenCalled();
        }));
    });
    describe('PUT /prepitems/daily/:restaurantId', () => {
        it('should update a daily prep item', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedPrepItem = {
                prep_list_id: 1,
                name: 'Slice Prosciutto',
                description: 'Thinly slice prosciutto',
                category: 1,
                status: 'complete'
            };
            // Mock the updateDailyPrepItem function
            jest.mocked(PrepItemController.updateDailyPrepItem).mockImplementation((req, res) => {
                return Promise.resolve(res.status(200).json({ success: true }));
            });
            const response = yield (0, supertest_1.default)(app)
                .put('/prepitems/daily/1')
                .send(updatedPrepItem);
            expect(response.status).toBe(200);
            expect(response.body).toEqual({ success: true });
            expect(PrepItemController.updateDailyPrepItem).toHaveBeenCalled();
        }));
    });
    describe('POST /prepitems/daily/:restaurantId', () => {
        it('should create daily prep items', () => __awaiter(void 0, void 0, void 0, function* () {
            const newDailyPrepItems = [
                { prep_item_id: 1, quantity: 5 },
                { prep_item_id: 2, quantity: 3 }
            ];
            const mockResponse = { message: 'Daily prep items created successfully' };
            // Mock the createDailyPrepItems function
            jest.mocked(PrepItemController.createDailyPrepItems).mockImplementation((req, res) => {
                res.status(201).json(mockResponse);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app)
                .post('/prepitems/daily/1')
                .send(newDailyPrepItems);
            expect(response.status).toBe(201);
            expect(response.body).toEqual(mockResponse);
            expect(PrepItemController.createDailyPrepItems).toHaveBeenCalled();
        }));
    });
    describe('POST /prepitems/:restaurantId', () => {
        it('should create a new prep item', () => __awaiter(void 0, void 0, void 0, function* () {
            const newPrepItem = {
                name: 'Dice Onions',
                description: 'Dice onions into small pieces',
                category: 2
            };
            const mockResponse = Object.assign({ prep_item_id: 3 }, newPrepItem);
            // Mock the createPrepItem function
            jest.mocked(PrepItemController.createPrepItem).mockImplementation((req, res) => {
                res.status(201).json(mockResponse);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app)
                .post('/prepitems/1')
                .send(newPrepItem);
            expect(response.status).toBe(201);
            expect(response.body).toEqual(mockResponse);
            expect(PrepItemController.createPrepItem).toHaveBeenCalled();
        }));
    });
});
