"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updatePrepItem = exports.createDailyPrepItems = exports.createPrepItem = exports.updateDailyPrepItem = exports.readDailyPrepItems = exports.readPrepItems = void 0;
const PrepItemDal = __importStar(require("./prepitem.dal"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const { validationResult } = require('express-validator');
// Mock data for testing when database is not available
const mockDailyPrepItems = [
    {
        prep_list_id: 1,
        name: 'Marinara Sauce',
        description: 'House marinara sauce for pasta dishes',
        note: 'Make extra for weekend',
        quantity: 5,
        unit: 'quarts',
        status: 'complete',
        category: 1,
        restaurant_id: 1,
        date: new Date().toISOString().split('T')[0],
        kitchen_department_id: 1
    },
    {
        prep_list_id: 2,
        name: 'Mashed Potatoes',
        description: 'Creamy garlic mashed potatoes',
        note: 'Use russet potatoes',
        quantity: 10,
        unit: 'pounds',
        status: 'in-progress',
        category: 1,
        restaurant_id: 1,
        date: new Date().toISOString().split('T')[0],
        kitchen_department_id: 1
    },
    {
        prep_list_id: 3,
        name: 'Caesar Dressing',
        description: 'House-made caesar dressing',
        note: '',
        quantity: 2,
        unit: 'quarts',
        status: 'todo',
        category: 4,
        restaurant_id: 1,
        date: new Date().toISOString().split('T')[0],
        kitchen_department_id: 2
    },
    {
        prep_list_id: 4,
        name: 'Chopped Vegetables',
        description: 'Diced onions, peppers, and celery',
        note: 'Fine dice for mirepoix',
        quantity: 5,
        unit: 'pounds',
        status: 'complete',
        category: 5,
        restaurant_id: 1,
        date: new Date().toISOString().split('T')[0],
        kitchen_department_id: 2
    },
    {
        prep_list_id: 5,
        name: 'Chocolate Ganache',
        description: 'Dark chocolate ganache for desserts',
        note: 'Use 70% chocolate',
        quantity: 3,
        unit: 'quarts',
        status: 'todo',
        category: 6,
        restaurant_id: 1,
        date: new Date().toISOString().split('T')[0],
        kitchen_department_id: 3
    }
];
// Retrieves all prep items for a restaurant
const readPrepItems = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitems.controller][readPrepItems][START]');
    try {
        let restaurantId = Number(req.params.restaurantId);
        console.log('resturantId', restaurantId);
        const response = yield PrepItemDal.getPrepItems(restaurantId);
        winston_middleware_1.logger.info('[prepitems.controller][readPrepItems][SUCCESS]', { response });
        res.status(200).json(response);
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitems.controller][readPrepItems][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when fetching prep items'
        });
    }
});
exports.readPrepItems = readPrepItems;
// Fetches daily prep items for a restaurant
const readDailyPrepItems = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][START]');
    try {
        let restaurantId = Number(req.params.restaurantId);
        try {
            // Try to get data from the database first
            const response = yield PrepItemDal.getDailyPrepItems(restaurantId);
            // If we got data from the database, return it
            if (response && response.length > 0) {
                winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][SUCCESS][DB]', { count: response.length });
                return res.status(200).json(response);
            }
            // If no data from database, create prep items from mock data
            winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][NO_DATA_FROM_DB] Creating from mock data');
            try {
                // First check if we need to create the prep items
                const existingPrepItems = yield PrepItemDal.getPrepItems(restaurantId);
                if (existingPrepItems.length === 0) {
                    winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][CREATING_PREP_ITEMS]');
                    // Create prep items from mock data
                    for (const mockItem of mockDailyPrepItems) {
                        yield PrepItemDal.createPrepItem(restaurantId, {
                            name: mockItem.name,
                            description: mockItem.description,
                            category: mockItem.category,
                            kitchen_department_id: mockItem.kitchen_department_id,
                            restaurant_id: restaurantId
                        }); // Use type assertion to bypass type checking
                    }
                }
                // Now create daily prep items for today
                const today = new Date();
                const dateId = parseInt(today.toISOString().split('T')[0].replace(/-/g, ''));
                // Create daily prep items for each mock item
                for (const mockItem of mockDailyPrepItems) {
                    // Get the prep item ID
                    const prepItemId = yield PrepItemDal.getPrepItemId(mockItem.name, restaurantId);
                    if (prepItemId) {
                        // Check if daily prep item already exists
                        const existingDailyItem = yield PrepItemDal.getDailyPrepItemByPrepId(prepItemId, restaurantId, dateId);
                        if (!existingDailyItem) {
                            // Create daily prep item
                            yield PrepItemDal.createDailyPrepItemSingle({
                                prepItemId: prepItemId,
                                restaurantId: restaurantId,
                                dateId: dateId,
                                quantity: String(mockItem.quantity),
                                status: mockItem.status,
                                notes: mockItem.note || null
                            });
                        }
                    }
                }
                // Now get the daily prep items again
                const createdItems = yield PrepItemDal.getDailyPrepItems(restaurantId);
                if (createdItems && createdItems.length > 0) {
                    winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][CREATED_FROM_MOCK]', { count: createdItems.length });
                    return res.status(200).json(createdItems);
                }
                // If still no data, fall back to mock data
                winston_middleware_1.logger.info('[prepitems.controller][readDailyPrepItems][FALLBACK_TO_MOCK]');
                return res.status(200).json(mockDailyPrepItems);
            }
            catch (createError) {
                winston_middleware_1.logger.error('[prepitems.controller][readDailyPrepItems][CREATE_ERROR]', { error: createError });
                // If error creating items, fall back to mock data
                return res.status(200).json(mockDailyPrepItems);
            }
        }
        catch (dbError) {
            // If database error, log it and fall back to mock data
            winston_middleware_1.logger.error('[prepitems.controller][readDailyPrepItems][DB_ERROR] Falling back to mock data', { dbError });
            return res.status(200).json(mockDailyPrepItems);
        }
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitems.controller][readDailyPrepItems][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when fetching prep items'
        });
    }
});
exports.readDailyPrepItems = readDailyPrepItems;
// Updates a daily prep item for a restaurant
const updateDailyPrepItem = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitems.controller][updateDailyPrepItems][START]', {
        body: req.body,
        restaurantId: req.params.restaurantId
    });
    try {
        let restaurantId = Number(req.params.restaurantId);
        // Validate that required fields are present
        if (!req.body.name) {
            winston_middleware_1.logger.error('[prepitems.controller][updateDailyPrepItems][VALIDATION_ERROR]', {
                error: 'Missing name field',
                body: req.body
            });
            return res.status(400).json({
                message: 'Missing required field: name is required'
            });
        }
        if (!req.body.status) {
            winston_middleware_1.logger.error('[prepitems.controller][updateDailyPrepItems][VALIDATION_ERROR]', {
                error: 'Missing status field',
                body: req.body
            });
            return res.status(400).json({
                message: 'Missing required field: status is required'
            });
        }
        // Validate status value
        const validStatuses = ['todo', 'in-progress', 'complete', 'pending'];
        if (!validStatuses.includes(req.body.status)) {
            winston_middleware_1.logger.error('[prepitems.controller][updateDailyPrepItems][VALIDATION_ERROR]', {
                error: 'Invalid status value',
                status: req.body.status,
                body: req.body
            });
            return res.status(400).json({
                message: `Invalid status value: ${req.body.status}. Must be one of: ${validStatuses.join(', ')}`
            });
        }
        // Ensure the item has a restaurant_id
        const itemToUpdate = Object.assign(Object.assign({}, req.body), { restaurant_id: restaurantId });
        winston_middleware_1.logger.info('[prepitems.controller][updateDailyPrepItems][PROCESSING]', {
            itemToUpdate
        });
        try {
            const response = yield PrepItemDal.updateDailyPrepItem(restaurantId, itemToUpdate);
            winston_middleware_1.logger.info('[prepitems.controller][updateDailyPrepItems][SUCCESS]', { response });
            return res.status(200).json(response);
        }
        catch (dalError) {
            const errorMessage = dalError instanceof Error ? dalError.message : 'Unknown error in DAL';
            const errorStack = dalError instanceof Error ? dalError.stack : undefined;
            winston_middleware_1.logger.error('[prepitems.controller][updateDailyPrepItem][DAL_ERROR]', {
                error: errorMessage,
                stack: errorStack,
                body: req.body
            });
            return res.status(500).json({
                message: 'There was an error when updating the prep item',
                error: errorMessage
            });
        }
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const errorStack = error instanceof Error ? error.stack : undefined;
        winston_middleware_1.logger.error('[prepitems.controller][updateDailyPrepItem][ERROR]', {
            error: errorMessage,
            stack: errorStack,
            body: req.body
        });
        res.status(500).json({
            message: 'There was an error when updating the prep item',
            error: errorMessage
        });
    }
});
exports.updateDailyPrepItem = updateDailyPrepItem;
// Creates a new prep item with validation
const createPrepItem = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.controller][createPrepItem][START]');
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        winston_middleware_1.logger.error('[prepitem.controller][createPrepItem][VALIDATION_ERROR]', { errors: errors.array() });
        return res.status(400).json({ errors: errors.array() });
    }
    try {
        let restaurantId = Number(req.params.restaurantId);
        let itemData = req.body;
        const response = yield PrepItemDal.createPrepItem(restaurantId, itemData);
        winston_middleware_1.logger.info('[prepitem.controller][createPrepItem][SUCCESS]', { response });
        res.status(201).json(response);
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.controller][createPrepItem][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when creating the prep item i am here'
        });
    }
});
exports.createPrepItem = createPrepItem;
const createDailyPrepItems = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('[prepitem.controller][createDailyPrepItems][START]');
    console.log("Received body.prepList :", req.body.prepList); // Log the entire incoming body
    // Validation check
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.error('[prepitem.controller][createDailyPrepItems][VALIDATION_ERROR]', { errors: errors.array() });
        return res.status(400).json({ errors: errors.array() });
    }
    try {
        const restaurantId = Number(req.params.restaurantId);
        console.log('[prepitem.controller][createDailyPrepItems][RESTAURANT_ID]', { restaurantId });
        const items = Array.isArray(req.body.prepList) ? req.body.prepList : [req.body.prepList];
        console.log('[prepitem.controller][createDailyPrepItems][ITEMS]', { items });
        const response = yield PrepItemDal.createDailyPrepItems(restaurantId, items); // Call the DAO function for arrays
        console.log('[prepitem.controller][createDailyPrepItems][RESPONSE]', { response });
        res.status(201).json(response);
    }
    catch (error) {
        console.error('[prepitem.controller][createDailyPrepItems][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when creating the prep items',
        });
    }
});
exports.createDailyPrepItems = createDailyPrepItems;
// Add this controller function
const updatePrepItem = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.controller][updatePrepItem][START]');
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        winston_middleware_1.logger.error('[prepitem.controller][updatePrepItem][VALIDATION_ERROR]', { errors: errors.array() });
        return res.status(400).json({ errors: errors.array() });
    }
    try {
        const restaurantId = Number(req.params.restaurantId);
        const prepItemId = Number(req.params.prepItemId);
        const itemData = req.body;
        const response = yield PrepItemDal.updatePrepItem(prepItemId, itemData);
        winston_middleware_1.logger.info('[prepitem.controller][updatePrepItem][SUCCESS]', { response });
        res.status(200).json(response);
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.controller][updatePrepItem][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when updating the prep item'
        });
    }
});
exports.updatePrepItem = updatePrepItem;
