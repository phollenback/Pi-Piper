"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDailyPrepItemSingle = exports.getDailyPrepItemByPrepId = exports.populateDailyPrepItems = exports.updateDailyPrepItem = exports.getPrepItemId = exports.deletePrepItem = exports.updatePrepItem = exports.createDailyPrepItems = exports.createPrepItem = exports.getDailyPrepItems = exports.getPrepItems = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const date_fns_1 = require("date-fns");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
// Retrieves all prep items for a given restaurant.
const getPrepItems = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][getPrepItems][START]', { restaurantId });
    try {
        const prepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId));
        // Map Drizzle PrepItem to the expected PrepItem format
        const formattedPrepItems = prepItems.map(item => ({
            prep_item_id: item.prepItemId,
            name: item.name,
            description: item.description || '',
            category: item.itemCategory || 0,
            kitchen_department_id: item.kitchenDepartmentId || 0,
            restaurant_id: item.restaurantId || 0,
        }));
        winston_middleware_1.logger.info('[prepitem.dao][getPrepItems][SUCCESS]', { prepItemsCount: formattedPrepItems.length });
        return formattedPrepItems;
    }
    catch (error) {
        const err = error; // Type cast to any to access properties
        winston_middleware_1.logger.error('[prepitem.dao][getPrepItems][ERROR]', {
            error,
            message: err.message,
            stack: err.stack
        });
        throw error;
    }
});
exports.getPrepItems = getPrepItems;
// Retrieves daily prep items for a given restaurant.
const getDailyPrepItems = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][getDailyPrepItems][START]', { restaurantId });
    try {
        const today = (0, date_fns_1.format)(new Date(), 'yyyy-MM-dd');
        const dateId = parseInt(today.replace(/-/g, ''));
        const dailyPrepItems = yield connection_1.db.select({
            prep_list_id: schema_1.factDailyPrepList.prepListId,
            name: schema_1.dimPrepItem.name,
            description: schema_1.dimPrepItem.description || '',
            note: schema_1.factDailyPrepList.notes || '',
            quantity: schema_1.factDailyPrepList.quantity,
            unit: schema_1.factDailyPrepList.unit || 'units',
            status: schema_1.factDailyPrepList.status,
            category: schema_1.dimPrepItem.itemCategory || 0,
            restaurant_id: schema_1.dimPrepItem.restaurantId || 0,
            kitchen_department_id: schema_1.dimPrepItem.kitchenDepartmentId || 0,
            date: (0, drizzle_orm_1.sql) `DATE_FORMAT(${schema_1.factDailyPrepList.dateId}, '%Y-%m-%d')`
        })
            .from(schema_1.factDailyPrepList)
            .innerJoin(schema_1.dimPrepItem, (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, schema_1.dimPrepItem.prepItemId))
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)));
        return dailyPrepItems.map(item => (Object.assign(Object.assign({}, item), { quantity: parseFloat(item.quantity), description: item.description || '', note: item.note || '', unit: item.unit || 'units', status: item.status || 'todo', category: item.category || 0, restaurant_id: item.restaurant_id || 0, kitchen_department_id: item.kitchen_department_id || 0 })));
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][getDailyPrepItems][ERROR]', { error });
        throw error;
    }
});
exports.getDailyPrepItems = getDailyPrepItems;
// Creates a new prep item.
const createPrepItem = (restaurantId, item) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][createPrepItem][START]', { restaurantId, item });
    try {
        const prepItemData = {
            name: item.name,
            description: item.description,
            itemCategory: item.category,
            kitchenDepartmentId: item.kitchen_department_id || 0,
            restaurantId: restaurantId,
        };
        yield connection_1.db.insert(schema_1.dimPrepItem).values(prepItemData);
        const newPrepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, item.name), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)))
            .orderBy((0, drizzle_orm_1.sql) `${schema_1.dimPrepItem.prepItemId} DESC`)
            .limit(1);
        const formattedPrepItems = newPrepItems.map(item => ({
            prep_item_id: item.prepItemId,
            name: item.name,
            description: item.description || '',
            category: item.itemCategory || 0,
            kitchen_department_id: item.kitchenDepartmentId || 0,
            restaurant_id: item.restaurantId || 0,
        }));
        winston_middleware_1.logger.info('[prepitem.dao][createPrepItem][SUCCESS]', { formattedPrepItems });
        return formattedPrepItems;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][createPrepItem][ERROR]', { error });
        throw error;
    }
});
exports.createPrepItem = createPrepItem;
// Creates daily prep items. Uses Promise.all for better performance.
const createDailyPrepItems = (restaurantId, items) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][createDailyPrepItems][START]', { restaurantId, itemsCount: items.length });
    try {
        const tomorrow = (0, date_fns_1.format)((0, date_fns_1.addDays)(new Date(), 1), 'yyyy-MM-dd');
        const dateId = parseInt(tomorrow.replace(/-/g, ''));
        const results = yield Promise.all(items.map((item) => __awaiter(void 0, void 0, void 0, function* () {
            // Get prep item ID
            const prepItems = yield connection_1.db.select()
                .from(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, item.name), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)))
                .limit(1);
            if (!prepItems || prepItems.length === 0) {
                winston_middleware_1.logger.error('[prepitem.dao][createDailyPrepItems][PREP_ITEM_NOT_FOUND]', { itemName: item.name, restaurantId });
                throw new Error(`PrepItem "${item.name}" not found for restaurant ${restaurantId}`);
            }
            const prepItemId = prepItems[0].prepItemId;
            // Create daily prep item
            const dailyPrepItemData = {
                prepItemId: prepItemId,
                restaurantId: restaurantId,
                dateId: dateId,
                quantity: String(item.quantity),
                status: item.status,
                notes: item.note || null,
            };
            return connection_1.db.insert(schema_1.factDailyPrepList).values(dailyPrepItemData);
        })));
        winston_middleware_1.logger.info('[prepitem.dao][createDailyPrepItems][SUCCESS]', { results });
        return results;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][createDailyPrepItems][ERROR]', { error });
        throw error;
    }
});
exports.createDailyPrepItems = createDailyPrepItems;
// Updates an existing prep item.
const updatePrepItem = (prepItemId, itemData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][updatePrepItem][START]', { prepItemId, itemData });
    try {
        yield connection_1.db.update(schema_1.dimPrepItem)
            .set({
            name: itemData.name,
            description: itemData.description,
            itemCategory: itemData.category,
            kitchenDepartmentId: itemData.kitchen_department_id,
        })
            .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId));
        const updatedPrepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId));
        const formattedPrepItems = updatedPrepItems.map(item => ({
            prep_item_id: item.prepItemId,
            name: item.name,
            description: item.description || '',
            category: item.itemCategory || 0,
            kitchen_department_id: item.kitchenDepartmentId || 0,
            restaurant_id: item.restaurantId || 0,
        }));
        winston_middleware_1.logger.info('[prepitem.dao][updatePrepItem][SUCCESS]', { formattedPrepItems });
        return formattedPrepItems;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][updatePrepItem][ERROR]', { error });
        throw error;
    }
});
exports.updatePrepItem = updatePrepItem;
// Deletes a prep item.
const deletePrepItem = (prepItemId, restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][deletePrepItem][START]', { prepItemId, restaurantId });
    try {
        // Get the prep item before deletion for return value
        const prepItemsToDelete = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)));
        // Delete the prep item
        yield connection_1.db.delete(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)));
        // Map to expected format
        const formattedPrepItems = prepItemsToDelete.map(item => ({
            prep_item_id: item.prepItemId,
            name: item.name,
            description: item.description || '',
            category: item.itemCategory || 0,
            kitchen_department_id: item.kitchenDepartmentId || 0,
            restaurant_id: item.restaurantId || 0,
        }));
        winston_middleware_1.logger.info('[prepitem.dao][deletePrepItem][SUCCESS]', { formattedPrepItems });
        return formattedPrepItems;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][deletePrepItem][ERROR]', { error });
        throw error;
    }
});
exports.deletePrepItem = deletePrepItem;
// Retrieves prep item ID by name and restaurant ID.  Improved error handling.
const getPrepItemId = (itemName, restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][getPrepItemId][START]', { itemName, restaurantId });
    try {
        const prepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, itemName), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)))
            .limit(1);
        if (prepItems && prepItems.length > 0) {
            return prepItems[0].prepItemId;
        }
        else {
            winston_middleware_1.logger.warn('[prepitem.dao][getPrepItemId][PREP_ITEM_NOT_FOUND]', { itemName, restaurantId });
            return null; // Return null if not found, instead of throwing an error
        }
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][getPrepItemId][ERROR]', { error });
        throw error;
    }
});
exports.getPrepItemId = getPrepItemId;
// Updates a daily prep item.
const updateDailyPrepItem = (restaurantId, item) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][START]', {
        restaurantId,
        item: {
            name: item.name,
            status: item.status,
            quantity: item.quantity,
            note: item.note
        }
    });
    try {
        // First get the prep item ID
        const prepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, item.name), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)))
            .limit(1);
        if (!prepItems || prepItems.length === 0) {
            // If the prep item doesn't exist, create it first
            winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][CREATING_PREP_ITEM]', {
                name: item.name,
                restaurantId
            });
            // Create the prep item
            const prepItemData = {
                name: item.name,
                description: item.description || '',
                itemCategory: item.category || 0,
                kitchenDepartmentId: item.kitchen_department_id || 0,
                restaurantId: restaurantId,
            };
            yield connection_1.db.insert(schema_1.dimPrepItem).values(prepItemData);
            // Get the newly created prep item
            const newPrepItems = yield connection_1.db.select()
                .from(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, item.name), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId)))
                .orderBy((0, drizzle_orm_1.sql) `${schema_1.dimPrepItem.prepItemId} DESC`)
                .limit(1);
            if (!newPrepItems || newPrepItems.length === 0) {
                throw new Error(`Failed to create prep item "${item.name}" for restaurant ${restaurantId}`);
            }
            var prepItemId = newPrepItems[0].prepItemId;
        }
        else {
            var prepItemId = prepItems[0].prepItemId;
        }
        winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][PREP_ITEM_FOUND]', { prepItemId });
        // Get the current date in YYYYMMDD format
        const today = new Date();
        const dateId = parseInt(today.toISOString().split('T')[0].replace(/-/g, ''));
        // Get the current status before updating
        const currentItems = yield connection_1.db.select({
            status: schema_1.factDailyPrepList.status,
            prepListId: schema_1.factDailyPrepList.prepListId
        })
            .from(schema_1.factDailyPrepList)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)))
            .limit(1);
        if (!currentItems || currentItems.length === 0) {
            // If the daily prep item doesn't exist, create it
            winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][CREATING_DAILY_PREP_ITEM]', {
                name: item.name,
                restaurantId,
                dateId
            });
            // Create the daily prep item with only the essential fields
            const dailyPrepItemData = {
                prepItemId: prepItemId,
                restaurantId: restaurantId,
                dateId: dateId,
                quantity: String(item.quantity || 0),
                status: item.status,
                notes: item.note || null,
            };
            try {
                yield connection_1.db.insert(schema_1.factDailyPrepList).values(dailyPrepItemData);
                winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][DAILY_PREP_ITEM_CREATED]');
            }
            catch (insertError) {
                winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][INSERT_ERROR]', {
                    error: insertError instanceof Error ? insertError.message : 'Unknown error',
                    stack: insertError instanceof Error ? insertError.stack : undefined
                });
                // Try with a more minimal set of fields if the first attempt failed
                try {
                    const minimalData = {
                        prepItemId: prepItemId,
                        restaurantId: restaurantId,
                        dateId: dateId,
                        quantity: String(item.quantity || 0),
                        status: item.status
                    };
                    yield connection_1.db.insert(schema_1.factDailyPrepList).values(minimalData);
                    winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][MINIMAL_DAILY_PREP_ITEM_CREATED]');
                }
                catch (minimalInsertError) {
                    winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][MINIMAL_INSERT_ERROR]', {
                        error: minimalInsertError instanceof Error ? minimalInsertError.message : 'Unknown error',
                        stack: minimalInsertError instanceof Error ? minimalInsertError.stack : undefined
                    });
                    throw new Error(`Failed to create daily prep item: ${minimalInsertError instanceof Error ? minimalInsertError.message : 'Unknown error'}`);
                }
            }
            var previousStatus = 'todo'; // Default status for new items
        }
        else {
            var previousStatus = ((_a = currentItems[0]) === null || _a === void 0 ? void 0 : _a.status) || 'todo';
        }
        const newStatus = item.status;
        winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][STATUS_CHANGE]', {
            previousStatus,
            newStatus,
            prepListId: currentItems && currentItems.length > 0 ? currentItems[0].prepListId : 'new'
        });
        // Update the daily prep item with only essential fields
        try {
            yield connection_1.db.update(schema_1.factDailyPrepList)
                .set({
                quantity: String(item.quantity),
                status: item.status,
                notes: item.note || null,
                updatedAt: new Date()
            })
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)));
            winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][UPDATE_SUCCESS]');
        }
        catch (updateError) {
            winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][UPDATE_ERROR]', {
                error: updateError instanceof Error ? updateError.message : 'Unknown error',
                stack: updateError instanceof Error ? updateError.stack : undefined
            });
            // Try with a more minimal set of fields if the first attempt failed
            try {
                yield connection_1.db.update(schema_1.factDailyPrepList)
                    .set({
                    quantity: String(item.quantity),
                    status: item.status
                })
                    .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)));
                winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][MINIMAL_UPDATE_SUCCESS]');
            }
            catch (minimalUpdateError) {
                winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][MINIMAL_UPDATE_ERROR]', {
                    error: minimalUpdateError instanceof Error ? minimalUpdateError.message : 'Unknown error',
                    stack: minimalUpdateError instanceof Error ? minimalUpdateError.stack : undefined
                });
                throw new Error(`Failed to update daily prep item: ${minimalUpdateError instanceof Error ? minimalUpdateError.message : 'Unknown error'}`);
            }
        }
        // If the item is being marked as complete, update inventory
        if (previousStatus !== 'complete' && newStatus === 'complete') {
            winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem] Item marked as complete, updating inventory', { prepItemId, restaurantId });
            try {
                // Import and call the IngredientService to update inventory
                const { IngredientService } = require('../services/ingredient.service');
                const result = yield IngredientService.updateInventoryFromPrepItem(prepItemId, restaurantId, 'complete');
                // Log any warnings or errors
                if (result.message) {
                    if (result.success) {
                        winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem] Inventory update result:', { message: result.message });
                        // If there are warnings about low stock or out of stock, add them to the prep item notes
                        if (result.message !== 'Inventory updated successfully') {
                            const updatedNotes = item.note
                                ? `${item.note}\n\n${result.message}`
                                : result.message;
                            try {
                                yield connection_1.db.update(schema_1.factDailyPrepList)
                                    .set({
                                    notes: updatedNotes
                                })
                                    .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)));
                            }
                            catch (notesUpdateError) {
                                winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][NOTES_UPDATE_ERROR]', {
                                    error: notesUpdateError instanceof Error ? notesUpdateError.message : 'Unknown error'
                                });
                                // Continue execution even if notes update fails
                            }
                        }
                    }
                    else {
                        winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem] Inventory update failed:', { message: result.message });
                    }
                }
            }
            catch (inventoryError) {
                winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][INVENTORY_UPDATE_ERROR]', {
                    error: inventoryError instanceof Error ? inventoryError.message : 'Unknown error',
                    stack: inventoryError instanceof Error ? inventoryError.stack : undefined
                });
                // Continue execution even if inventory update fails
            }
        }
        // Get the updated daily prep items
        const updatedItems = yield connection_1.db.select({
            prep_list_id: schema_1.factDailyPrepList.prepListId,
            name: schema_1.dimPrepItem.name,
            description: schema_1.dimPrepItem.description,
            quantity: schema_1.factDailyPrepList.quantity,
            status: schema_1.factDailyPrepList.status,
            notes: schema_1.factDailyPrepList.notes,
            category: schema_1.dimPrepItem.itemCategory,
            restaurant_id: schema_1.dimPrepItem.restaurantId,
            date: (0, drizzle_orm_1.sql) `DATE_FORMAT(${schema_1.factDailyPrepList.dateId}, '%Y-%m-%d')`
        })
            .from(schema_1.factDailyPrepList)
            .innerJoin(schema_1.dimPrepItem, (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, schema_1.dimPrepItem.prepItemId))
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.dimPrepItem.name, item.name), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)));
        // Map the response to include the note field
        const formattedItems = updatedItems.map(item => (Object.assign(Object.assign({}, item), { note: item.notes || '', kitchen_department_id: 0, unit: 'units' // Default value if not available
         })));
        winston_middleware_1.logger.info('[prepitem.dao][updateDailyPrepItem][SUCCESS]', {
            itemCount: formattedItems.length
        });
        return formattedItems;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][updateDailyPrepItem][ERROR]', {
            error: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined,
            item: {
                name: item.name,
                status: item.status
            }
        });
        throw error;
    }
});
exports.updateDailyPrepItem = updateDailyPrepItem;
const populateDailyPrepItems = (restaurantId, dateId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][populateDailyPrepItems][START]', { restaurantId, dateId });
    try {
        // Fetch all prep items for the restaurant
        const prepItems = yield connection_1.db.select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId));
        // Create daily prep items for each prep item
        yield Promise.all(prepItems.map((item) => __awaiter(void 0, void 0, void 0, function* () {
            const dailyPrepItemData = {
                prepItemId: item.prepItemId,
                restaurantId: restaurantId,
                dateId: dateId,
                quantity: '0', // Default quantity
                status: 'todo', // Default status
                notes: null, // No notes initially
            };
            yield connection_1.db.insert(schema_1.factDailyPrepList).values(dailyPrepItemData);
        })));
        winston_middleware_1.logger.info('[prepitem.dao][populateDailyPrepItems][SUCCESS]', { prepItemsCount: prepItems.length });
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][populateDailyPrepItems][ERROR]', { error });
        throw error;
    }
});
exports.populateDailyPrepItems = populateDailyPrepItems;
// Get a daily prep item by prep item ID, restaurant ID, and date ID
const getDailyPrepItemByPrepId = (prepItemId, restaurantId, dateId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][getDailyPrepItemByPrepId][START]', { prepItemId, restaurantId, dateId });
    try {
        // Only select fields that exist in the database
        const dailyPrepItems = yield connection_1.db.select({
            prepListId: schema_1.factDailyPrepList.prepListId,
            prepItemId: schema_1.factDailyPrepList.prepItemId,
            restaurantId: schema_1.factDailyPrepList.restaurantId,
            dateId: schema_1.factDailyPrepList.dateId,
            quantity: schema_1.factDailyPrepList.quantity,
            unit: schema_1.factDailyPrepList.unit,
            status: schema_1.factDailyPrepList.status,
            assignedTo: schema_1.factDailyPrepList.assignedTo,
            completedBy: schema_1.factDailyPrepList.completedBy,
            notes: schema_1.factDailyPrepList.notes,
            createdAt: schema_1.factDailyPrepList.createdAt,
            updatedAt: schema_1.factDailyPrepList.updatedAt
        })
            .from(schema_1.factDailyPrepList)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.prepItemId, prepItemId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.restaurantId, restaurantId), (0, drizzle_orm_1.eq)(schema_1.factDailyPrepList.dateId, dateId)))
            .limit(1);
        if (dailyPrepItems && dailyPrepItems.length > 0) {
            winston_middleware_1.logger.info('[prepitem.dao][getDailyPrepItemByPrepId][SUCCESS]', { dailyPrepItem: dailyPrepItems[0] });
            return dailyPrepItems[0];
        }
        else {
            winston_middleware_1.logger.info('[prepitem.dao][getDailyPrepItemByPrepId][NOT_FOUND]', { prepItemId, restaurantId, dateId });
            return null;
        }
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][getDailyPrepItemByPrepId][ERROR]', { error });
        throw error;
    }
});
exports.getDailyPrepItemByPrepId = getDailyPrepItemByPrepId;
// Create a single daily prep item
const createDailyPrepItemSingle = (dailyPrepItemData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][createDailyPrepItemSingle][START]', { dailyPrepItemData });
    try {
        // Only include fields that exist in the database
        const insertData = {
            prepItemId: dailyPrepItemData.prepItemId,
            restaurantId: dailyPrepItemData.restaurantId,
            dateId: dailyPrepItemData.dateId,
            quantity: dailyPrepItemData.quantity,
            unit: dailyPrepItemData.unit,
            status: dailyPrepItemData.status,
            assignedTo: dailyPrepItemData.assignedTo,
            completedBy: dailyPrepItemData.completedBy,
            notes: dailyPrepItemData.notes,
        };
        const result = yield connection_1.db.insert(schema_1.factDailyPrepList).values(insertData);
        winston_middleware_1.logger.info('[prepitem.dao][createDailyPrepItemSingle][SUCCESS]', { result });
        return result;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][createDailyPrepItemSingle][ERROR]', { error });
        throw error;
    }
});
exports.createDailyPrepItemSingle = createDailyPrepItemSingle;
