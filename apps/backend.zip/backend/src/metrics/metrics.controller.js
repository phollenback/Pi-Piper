"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordPrepCompletion = exports.calculateMetrics = exports.getMetricsInRange = exports.getLatestMetrics = void 0;
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const winston_middleware_1 = require("../middleware/winston.middleware");
const date_fns_1 = require("date-fns");
const metrics_service_1 = require("../services/metrics.service");
/**
 * Get the latest metrics for a restaurant
 */
const getLatestMetrics = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { restaurantId } = req.params;
        if (!restaurantId) {
            return res.status(400).json({ error: 'Restaurant ID is required' });
        }
        winston_middleware_1.logger.info(`[metrics.controller][getLatestMetrics] Getting latest metrics for restaurant ${restaurantId}`);
        // Get the latest metrics for the restaurant
        const metrics = yield connection_1.db.select()
            .from(schema_1.factRestaurantMetrics)
            .where((0, drizzle_orm_1.eq)(schema_1.factRestaurantMetrics.restaurantId, parseInt(restaurantId)))
            .orderBy((0, drizzle_orm_1.desc)(schema_1.factRestaurantMetrics.date))
            .limit(1);
        if (metrics.length === 0) {
            return res.status(404).json({ error: 'No metrics found for this restaurant' });
        }
        return res.status(200).json(metrics[0]);
    }
    catch (error) {
        winston_middleware_1.logger.error('[metrics.controller][getLatestMetrics][ERROR]', error);
        return res.status(500).json({ error: 'Failed to get metrics' });
    }
});
exports.getLatestMetrics = getLatestMetrics;
/**
 * Get metrics for a restaurant within a date range
 */
const getMetricsInRange = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { restaurantId } = req.params;
        const { startDate, endDate } = req.query;
        if (!restaurantId) {
            return res.status(400).json({ error: 'Restaurant ID is required' });
        }
        // Default to last 30 days if no date range is provided
        const end = endDate ? new Date(endDate) : new Date();
        const start = startDate ? new Date(startDate) : (0, date_fns_1.subDays)(end, 30);
        winston_middleware_1.logger.info(`[metrics.controller][getMetricsInRange] Getting metrics for restaurant ${restaurantId} from ${(0, date_fns_1.format)(start, 'yyyy-MM-dd')} to ${(0, date_fns_1.format)(end, 'yyyy-MM-dd')}`);
        // Get metrics within the date range
        const metrics = yield connection_1.db.select()
            .from(schema_1.factRestaurantMetrics)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.factRestaurantMetrics.restaurantId, parseInt(restaurantId)), (0, drizzle_orm_1.gte)(schema_1.factRestaurantMetrics.date, start), (0, drizzle_orm_1.lte)(schema_1.factRestaurantMetrics.date, end)))
            .orderBy(schema_1.factRestaurantMetrics.date);
        return res.status(200).json(metrics);
    }
    catch (error) {
        winston_middleware_1.logger.error('[metrics.controller][getMetricsInRange][ERROR]', error);
        return res.status(500).json({ error: 'Failed to get metrics' });
    }
});
exports.getMetricsInRange = getMetricsInRange;
/**
 * Manually trigger metrics calculation for a restaurant
 */
const calculateMetrics = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { restaurantId } = req.params;
        if (!restaurantId) {
            return res.status(400).json({ error: 'Restaurant ID is required' });
        }
        winston_middleware_1.logger.info(`[metrics.controller][calculateMetrics] Calculating metrics for restaurant ${restaurantId}`);
        // Calculate metrics for the restaurant
        yield (0, metrics_service_1.updateRestaurantMetrics)(parseInt(restaurantId));
        return res.status(200).json({ message: 'Metrics calculation triggered successfully' });
    }
    catch (error) {
        winston_middleware_1.logger.error('[metrics.controller][calculateMetrics][ERROR]', error);
        return res.status(500).json({ error: 'Failed to calculate metrics' });
    }
});
exports.calculateMetrics = calculateMetrics;
/**
 * Record prep list completion time for a restaurant
 */
const recordPrepCompletion = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { restaurantId } = req.params;
        const { completionTime, dateId } = req.body;
        if (!restaurantId || !completionTime || !dateId) {
            return res.status(400).json({
                error: 'Restaurant ID, completion time, and date ID are required'
            });
        }
        winston_middleware_1.logger.info(`[metrics.controller][recordPrepCompletion] Recording prep completion for restaurant ${restaurantId} on date ${dateId}`);
        // Insert the completion record
        yield connection_1.db.insert(schema_1.factPrepCompletion).values({
            restaurantId: parseInt(restaurantId),
            dateId: dateId,
            completionTime: new Date(completionTime)
        });
        // Trigger metrics calculation to update the average prep time
        yield (0, metrics_service_1.updateRestaurantMetrics)(parseInt(restaurantId));
        return res.status(200).json({
            message: 'Prep list completion time recorded successfully',
            restaurantId,
            dateId,
            completionTime
        });
    }
    catch (error) {
        winston_middleware_1.logger.error('[metrics.controller][recordPrepCompletion][ERROR]', error);
        return res.status(500).json({ error: 'Failed to record prep list completion time' });
    }
});
exports.recordPrepCompletion = recordPrepCompletion;
