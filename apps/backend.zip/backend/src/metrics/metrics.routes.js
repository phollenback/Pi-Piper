"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const metrics_controller_1 = require("./metrics.controller");
const asyncHandler_1 = __importDefault(require("../util/asyncHandler"));
const router = (0, express_1.Router)();
// Get metrics for a restaurant within a date range
router
    .route('/range/:restaurantId')
    .get((0, asyncHandler_1.default)(metrics_controller_1.getMetricsInRange));
// Manually trigger metrics calculation for a restaurant
router
    .route('/calculate/:restaurantId')
    .post((0, asyncHandler_1.default)(metrics_controller_1.calculateMetrics));
// Record prep list completion time for a restaurant
router
    .route('/record-prep-completion/:restaurantId')
    .post((0, asyncHandler_1.default)(metrics_controller_1.recordPrepCompletion));
// Get latest metrics for a restaurant
router
    .route('/:restaurantId')
    .get((0, asyncHandler_1.default)(metrics_controller_1.getLatestMetrics));
exports.default = router;
