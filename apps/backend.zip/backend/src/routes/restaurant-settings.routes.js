"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const restaurant_settings_controller_1 = require("../controllers/restaurant-settings.controller");
const asyncHandler_1 = __importDefault(require("../util/asyncHandler"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const router = express_1.default.Router();
// Apply logging middleware
router.use(winston_middleware_1.responseTimeLogger);
// Get restaurant settings
router.get('/:restaurantId', (0, asyncHandler_1.default)(restaurant_settings_controller_1.RestaurantSettingsController.getSettings));
// Update low stock threshold
router.put('/:restaurantId/low-stock-threshold', (0, asyncHandler_1.default)(restaurant_settings_controller_1.RestaurantSettingsController.updateLowStockThreshold));
exports.default = router;
