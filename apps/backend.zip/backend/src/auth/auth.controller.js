"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.protectedRoute = exports.login = void 0;
const pg_connector_1 = require("../services/pg.connector");
const bcrypt_1 = __importDefault(require("bcrypt"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const login = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { username, password } = req.body;
        // Check for missing credentials
        if (!username || !password) {
            res.status(400).json({ message: 'Username and password are required' });
            return;
        }
        const [user] = yield (0, pg_connector_1.execute)('SELECT user_id, username, password, role, restaurant_id, status FROM dim_users WHERE username = ? AND status = ?', [username, 'active']);
        if (!user) {
            res.status(401).json({ message: 'Invalid credentials' });
            return;
        }
        const isValidPassword = yield bcrypt_1.default.compare(password, user.password);
        if (!isValidPassword) {
            res.status(401).json({ message: 'Invalid credentials' });
            return;
        }
        res.status(200).json({
            id: user.user_id.toString(),
            name: user.username,
            email: user.username,
            role: user.role,
            restaurant_id: user.restaurant_id
        });
    }
    catch (error) {
        winston_middleware_1.logger.error('[auth.controller][login][ERROR]', { error });
        res.status(500).json({ message: 'Server error' });
    }
});
exports.login = login;
// Protected route handler that requires authentication
const protectedRoute = (req, res) => {
    // For this route, verifyJWT should be applied in the router file
    // If it reaches here, user is already authenticated
    const authReq = req;
    res.json({
        message: 'Access granted to protected route',
        user: authReq.user
    });
};
exports.protectedRoute = protectedRoute;
