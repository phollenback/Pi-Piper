"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const auth_routes_1 = __importDefault(require("./auth.routes"));
const pg_connector_1 = require("../services/pg.connector");
const bcrypt_1 = __importDefault(require("bcrypt"));
// Mock the database execute function
jest.mock('../services/pg.connector', () => ({
    execute: jest.fn()
}));
// Mock bcrypt
jest.mock('bcrypt', () => ({
    compare: jest.fn()
}));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use('/auth', auth_routes_1.default);
describe('Auth Routes', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('POST /auth/login', () => {
        it('should login successfully with valid credentials', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockUser = {
                user_id: 1,
                username: 'testuser',
                password: 'hashedpass',
                role: 'owner',
                restaurant_id: 1,
                status: 'active'
            };
            pg_connector_1.execute.mockResolvedValueOnce([mockUser]);
            bcrypt_1.default.compare.mockResolvedValueOnce(true);
            const response = yield (0, supertest_1.default)(app)
                .post('/auth/login')
                .send({
                username: 'testuser',
                password: 'password'
            });
            expect(response.status).toBe(200);
            expect(response.body).toHaveProperty('id');
            expect(response.body).toHaveProperty('role');
        }));
        it('should fail with invalid credentials', () => __awaiter(void 0, void 0, void 0, function* () {
            pg_connector_1.execute.mockResolvedValueOnce([]);
            const response = yield (0, supertest_1.default)(app)
                .post('/auth/login')
                .send({
                username: 'wronguser',
                password: 'wrongpass'
            });
            expect(response.status).toBe(401);
            expect(response.body).toHaveProperty('message', 'Invalid credentials');
        }));
        it('should fail with missing credentials', () => __awaiter(void 0, void 0, void 0, function* () {
            const response = yield (0, supertest_1.default)(app)
                .post('/auth/login')
                .send({});
            expect(response.status).toBe(400);
            expect(response.body).toHaveProperty('message');
        }));
    });
    afterAll(done => {
        app.listen().close(done);
    });
});
