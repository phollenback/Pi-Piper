"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authConfig = void 0;
const credentials_1 = __importDefault(require("@auth/express/providers/credentials"));
const pg_connector_1 = require("../services/pg.connector");
const bcrypt_1 = __importDefault(require("bcrypt"));
const winston_middleware_1 = require("../middleware/winston.middleware");
exports.authConfig = {
    providers: [
        (0, credentials_1.default)({
            authorize(credentials) {
                return __awaiter(this, void 0, void 0, function* () {
                    try {
                        if (!(credentials === null || credentials === void 0 ? void 0 : credentials.username) || !(credentials === null || credentials === void 0 ? void 0 : credentials.password) ||
                            !(credentials === null || credentials === void 0 ? void 0 : credentials.restaurant_id) || !(credentials === null || credentials === void 0 ? void 0 : credentials.role)) {
                            return null;
                        }
                        const creds = {
                            username: credentials.username,
                            password: credentials.password,
                            restaurant_id: credentials.restaurant_id,
                            role: credentials.role
                        };
                        const [user] = (yield (0, pg_connector_1.execute)(`SELECT user_id, username, password, role, restaurant_id, status 
             FROM dim_users 
             WHERE username = ? 
             AND restaurant_id = ?
             AND status = 'active'`, [creds.username, creds.restaurant_id]));
                        if (!user) {
                            winston_middleware_1.logger.error('[auth.config][authorize] User not found');
                            return null;
                        }
                        const isValidPassword = yield bcrypt_1.default.compare(creds.password, user.password);
                        if (!isValidPassword) {
                            winston_middleware_1.logger.error('[auth.config][authorize] Invalid password');
                            return null;
                        }
                        // Verify role matches
                        if (user.role !== creds.role && user.role !== 'owner') {
                            winston_middleware_1.logger.error('[auth.config][authorize] Invalid role');
                            return null;
                        }
                        winston_middleware_1.logger.info('[auth.config][authorize] Login successful', {
                            userId: user.user_id,
                            role: user.role
                        });
                        return {
                            id: user.user_id.toString(),
                            name: user.username,
                            role: user.role,
                            restaurant_id: user.restaurant_id
                        };
                    }
                    catch (error) {
                        winston_middleware_1.logger.error('[auth.config][authorize][ERROR]', { error });
                        return null;
                    }
                });
            }
        })
    ],
    callbacks: {
        jwt(_a) {
            return __awaiter(this, arguments, void 0, function* ({ token, user }) {
                if (user) {
                    token.role = user.role;
                    token.restaurant_id = user.restaurant_id;
                }
                return token;
            });
        },
        session(_a) {
            return __awaiter(this, arguments, void 0, function* ({ session, token }) {
                if (token) {
                    session.user.role = token.role;
                    session.user.restaurant_id = token.restaurant_id;
                }
                return session;
            });
        }
    },
    secret: process.env.AUTH_SECRET,
    trustHost: true
};
