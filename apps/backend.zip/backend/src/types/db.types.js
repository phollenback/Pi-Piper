"use strict";
/**
 * Database type definitions generated from Drizzle schema
 *
 * This file exports TypeScript interfaces for all database tables defined in the schema.
 * It provides type safety for database operations throughout the application.
 */
Object.defineProperty(exports, "__esModule", { value: true });
