"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllPricing = exports.getSuggestions = exports.deleteIngredient = exports.updateIngredient = exports.createIngredient = exports.getIngredientById = exports.getIngredients = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
// Retrieves all ingredients for a given restaurant.
const getIngredients = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getIngredients][START]', { restaurantId });
    try {
        const ingredients = yield connection_1.db.select()
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId));
        winston_middleware_1.logger.info('[ingredient.dao][getIngredients][SUCCESS]');
        return ingredients;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getIngredients][ERROR]', { error });
        throw error; // Re-throwing the error allows the calling function to handle it.
    }
});
exports.getIngredients = getIngredients;
// Get an ingredient by ID
const getIngredientById = (ingredientId, restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getIngredientById][START]', { ingredientId, restaurantId });
    try {
        const ingredients = yield connection_1.db.select()
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)))
            .limit(1);
        const ingredient = ingredients[0];
        winston_middleware_1.logger.info('[ingredient.dao][getIngredientById][SUCCESS]', { ingredient });
        return ingredient;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getIngredientById][ERROR]', { error, ingredientId, restaurantId });
        throw error;
    }
});
exports.getIngredientById = getIngredientById;
// Creates a new ingredient for a given restaurant.
const createIngredient = (restaurantId, ingredientData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][createIngredient][START]', { restaurantId, ingredientData });
    try {
        // Ensure restaurantId is set
        const dataWithRestaurantId = Object.assign(Object.assign({}, ingredientData), { restaurantId });
        yield connection_1.db.insert(schema_1.dimIngredient)
            .values(dataWithRestaurantId);
        // Get the newly created ingredient
        const ingredients = yield connection_1.db.select()
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientName, ingredientData.ingredientName), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)))
            .orderBy((0, drizzle_orm_1.desc)(schema_1.dimIngredient.createdAt))
            .limit(1);
        const newIngredient = ingredients[0];
        if (!newIngredient) {
            throw new Error('Failed to retrieve created ingredient');
        }
        winston_middleware_1.logger.info('[ingredient.dao][createIngredient][SUCCESS]', { newIngredient });
        return newIngredient;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][createIngredient][ERROR]', { error });
        throw error;
    }
});
exports.createIngredient = createIngredient;
// Updates an existing ingredient.
const updateIngredient = (ingredientId, restaurantId, ingredientData) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][updateIngredient][START]', { ingredientId, restaurantId, ingredientData });
    try {
        // Map the ingredient data to the schema fields
        const updateData = {};
        if (ingredientData.ingredientName)
            updateData.ingredientName = ingredientData.ingredientName;
        if (ingredientData.unit)
            updateData.unit = ingredientData.unit;
        if (ingredientData.unitPrice)
            updateData.unitPrice = ingredientData.unitPrice;
        if (ingredientData.categoryId)
            updateData.categoryId = ingredientData.categoryId;
        yield connection_1.db.update(schema_1.dimIngredient)
            .set(updateData)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)));
        // Fetch the updated ingredient
        const ingredients = yield connection_1.db.select()
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)))
            .limit(1);
        if (ingredients.length === 0) {
            throw new Error('Ingredient not found after update');
        }
        const updatedIngredient = ingredients[0];
        // Map the schema fields back to the Ingredient interface
        const result = {
            ingredientId: updatedIngredient.ingredientId,
            ingredientName: updatedIngredient.ingredientName,
            unit: updatedIngredient.unit || '',
            unitPrice: updatedIngredient.unitPrice,
            categoryId: updatedIngredient.categoryId,
            restaurantId: updatedIngredient.restaurantId,
            supplierId: updatedIngredient.supplierId,
            parLevel: updatedIngredient.parLevel,
            currentStock: updatedIngredient.currentStock,
            reorderPoint: updatedIngredient.reorderPoint,
            isActive: updatedIngredient.isActive,
            createdAt: updatedIngredient.createdAt,
            updatedAt: updatedIngredient.updatedAt
        };
        winston_middleware_1.logger.info('[ingredient.dao][updateIngredient][SUCCESS]', { updatedIngredient: result });
        return result;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][updateIngredient][ERROR]', { error });
        throw error;
    }
});
exports.updateIngredient = updateIngredient;
// Deletes an ingredient.
const deleteIngredient = (ingredientId, restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][deleteIngredient][START]', { ingredientId, restaurantId });
    try {
        yield connection_1.db.delete(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.dimIngredient.ingredientId, ingredientId), (0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId)));
        winston_middleware_1.logger.info('[ingredient.dao][deleteIngredient][SUCCESS]', { ingredientId, restaurantId });
        return true;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][deleteIngredient][ERROR]', { error });
        throw error;
    }
});
exports.deleteIngredient = deleteIngredient;
// Gets suggestions for ingredients that need to be ordered
const getSuggestions = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getSuggestions][START]', { restaurantId });
    try {
        const suggestions = yield connection_1.db.select({
            ingredientId: schema_1.dimIngredient.ingredientId,
            ingredientName: schema_1.dimIngredient.ingredientName,
            inv: (0, drizzle_orm_1.sql) `CAST(${schema_1.dimIngredient.currentStock} AS DECIMAL(10,2))`
        })
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId));
        const result = suggestions.map(item => {
            var _a;
            return ({
                ingredientId: item.ingredientId,
                ingredientName: item.ingredientName,
                inv: (_a = item.inv) !== null && _a !== void 0 ? _a : 0
            });
        });
        winston_middleware_1.logger.info('[ingredient.dao][getSuggestions][SUCCESS]', { result });
        return result;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getSuggestions][ERROR]', { error });
        throw error;
    }
});
exports.getSuggestions = getSuggestions;
// Get Sysco pricing
const getSyscoPricing = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getSyscoPricing][START]', { restaurantId });
    try {
        const ingredients = yield connection_1.db.select({
            ingredientId: schema_1.dimIngredient.ingredientId,
            ingredientName: schema_1.dimIngredient.ingredientName,
            unit: schema_1.dimIngredient.unit,
            unitPrice: schema_1.dimIngredient.unitPrice,
            supplier: (0, drizzle_orm_1.sql) `'Sysco'`
        })
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId));
        winston_middleware_1.logger.info('[ingredient.dao][getSyscoPricing][SUCCESS]', { ingredients });
        return ingredients;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getSyscoPricing][ERROR]', { error });
        throw error;
    }
});
// Get US Foods pricing
const getUsFoodsPricing = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getUsFoodsPricing][START]', { restaurantId });
    try {
        const ingredients = yield connection_1.db.select({
            ingredientId: schema_1.dimIngredient.ingredientId,
            ingredientName: schema_1.dimIngredient.ingredientName,
            unit: schema_1.dimIngredient.unit,
            unitPrice: schema_1.dimIngredient.unitPrice,
            supplier: (0, drizzle_orm_1.sql) `'US Foods'`
        })
            .from(schema_1.dimIngredient)
            .where((0, drizzle_orm_1.eq)(schema_1.dimIngredient.restaurantId, restaurantId));
        winston_middleware_1.logger.info('[ingredient.dao][getUsFoodsPricing][SUCCESS]', { ingredients });
        return ingredients;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getUsFoodsPricing][ERROR]', { error });
        throw error;
    }
});
// Get all pricing
const getAllPricing = (restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.dao][getAllPricing][START]', { restaurantId });
    try {
        const syscoPricing = yield getSyscoPricing(restaurantId);
        const usFoodsPricing = yield getUsFoodsPricing(restaurantId);
        const allPricing = [...syscoPricing, ...usFoodsPricing];
        winston_middleware_1.logger.info('[ingredient.dao][getAllPricing][SUCCESS]', { allPricing });
        return allPricing;
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.dao][getAllPricing][ERROR]', { error });
        throw error;
    }
});
exports.getAllPricing = getAllPricing;
