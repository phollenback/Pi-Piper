"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const ingredient_routes_1 = __importDefault(require("./ingredient.routes"));
const IngredientController = __importStar(require("./ingredient.controller"));
// Mock the ingredient controller
jest.mock('./ingredient.controller', () => ({
    readIngredients: jest.fn(),
    readInventory: jest.fn(),
    readSuggestions: jest.fn(),
    readPricing: jest.fn(),
    createIngredient: jest.fn(),
    updateIngredient: jest.fn(),
    deleteIngredient: jest.fn()
}));
// Mock express-validator
jest.mock('express-validator', () => ({
    checkSchema: () => [(_req, _res, next) => next()],
    validationResult: jest.fn(() => ({ isEmpty: () => true }))
}));
// Mock the database connection
jest.mock('../services/pg.connector', () => ({
    pool: {
        end: jest.fn()
    }
}));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use('/ingredients', ingredient_routes_1.default);
describe('Ingredient API', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('GET /ingredients/:restaurantId', () => {
        it('should return ingredients for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockIngredients = [
                { ingredient_id: 1, ingredient_name: 'Chicken', ingredient_category: 1, restaurant_id: 1 },
                { ingredient_id: 2, ingredient_name: 'Beef', ingredient_category: 1, restaurant_id: 1 }
            ];
            // Mock the readIngredients function
            jest.mocked(IngredientController.readIngredients).mockImplementation((req, res) => {
                res.status(200).json(mockIngredients);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/ingredients/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockIngredients);
            expect(IngredientController.readIngredients).toHaveBeenCalled();
        }));
        it('should handle errors when fetching ingredients', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the readIngredients function to simulate an error
            jest.mocked(IngredientController.readIngredients).mockImplementation((req, res) => {
                res.status(500).json({ error: 'Failed to fetch ingredients' });
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/ingredients/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ error: 'Failed to fetch ingredients' });
        }));
    });
    describe('GET /ingredients/inventory/:restaurantId', () => {
        it('should return inventory status for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockInventory = [
                { ingredient_id: 1, ingredient_name: 'Chicken', current_stock: 10, par_level: 15 },
                { ingredient_id: 2, ingredient_name: 'Beef', current_stock: 5, par_level: 10 }
            ];
            // Mock the readInventory function
            jest.mocked(IngredientController.readInventory).mockImplementation((req, res) => {
                res.status(200).json(mockInventory);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/ingredients/inventory/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockInventory);
            expect(IngredientController.readInventory).toHaveBeenCalled();
        }));
    });
    describe('POST /ingredients/:restaurantId', () => {
        it('should create a new ingredient', () => __awaiter(void 0, void 0, void 0, function* () {
            const newIngredient = {
                ingredient_name: 'Pork',
                ingredient_category: 1,
                restaurant_id: 1
            };
            const mockResponse = Object.assign({ ingredient_id: 3 }, newIngredient);
            // Mock the createIngredient function
            jest.mocked(IngredientController.createIngredient).mockImplementation((req, res) => {
                res.status(201).json(mockResponse);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app)
                .post('/ingredients/1')
                .send(newIngredient);
            expect(response.status).toBe(201);
            expect(response.body).toEqual(mockResponse);
            expect(IngredientController.createIngredient).toHaveBeenCalled();
        }));
    });
    describe('PUT /ingredients/ingredient', () => {
        it('should update an existing ingredient', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedIngredient = {
                ingredient_id: 1,
                ingredient_name: 'Chicken Breast',
                ingredient_category: 1,
                restaurant_id: 1
            };
            // Mock the updateIngredient function
            jest.mocked(IngredientController.updateIngredient).mockImplementation((req, res) => {
                res.status(200).json(updatedIngredient);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app)
                .put('/ingredients/1/1')
                .send(updatedIngredient);
            expect(response.status).toBe(200);
            expect(response.body).toEqual(updatedIngredient);
            expect(IngredientController.updateIngredient).toHaveBeenCalled();
        }));
    });
    describe('DELETE /ingredients/:restaurantId/:ingredientId', () => {
        it('should delete an ingredient', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockResponse = { message: 'Ingredient deleted successfully' };
            // Mock the deleteIngredient function
            jest.mocked(IngredientController.deleteIngredient).mockImplementation((req, res) => {
                res.status(200).json(mockResponse);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).delete('/ingredients/1/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockResponse);
            expect(IngredientController.deleteIngredient).toHaveBeenCalled();
        }));
    });
});
