"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const IngredientController = __importStar(require("./ingredient.controller"));
const ingredient_model_1 = require("./ingredient.model");
const asyncHandler_1 = __importDefault(require("../util/asyncHandler"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const { checkSchema } = require('express-validator');
const router = (0, express_1.Router)();
// Apply logging middleware
router.use(winston_middleware_1.responseTimeLogger);
router.use(winston_middleware_1.requestLogger);
// Retrieve all ingredients for a restaurant
router
    .get('/:restaurantId', (0, asyncHandler_1.default)(IngredientController.readIngredients));
// Get inventory status for a restaurant
router
    .get('/inventory/:restaurantId', (0, asyncHandler_1.default)(IngredientController.getInventoryStatus));
// Get ingredient suggestions for a restaurant
router
    .get('/suggestions/:restaurantId', (0, asyncHandler_1.default)(IngredientController.readSuggestions));
// Get pricing information for restaurant ingredients
router
    .get('/pricing/:restaurantId', (0, asyncHandler_1.default)(IngredientController.readPricing));
// Create new ingredient with validation
router
    .post('/:restaurantId', checkSchema(ingredient_model_1.IngredientSchema), (0, asyncHandler_1.default)(IngredientController.createIngredient));
// Update existing ingredient with validation
router
    .put('/:restaurantId/:ingredientId', checkSchema(ingredient_model_1.IngredientSchema), (0, asyncHandler_1.default)(IngredientController.updateIngredient));
// Remove ingredient from restaurant
router
    .delete('/:restaurantId/:ingredientId', (0, asyncHandler_1.default)(IngredientController.deleteIngredient));
// Complete a prep item (updated to include restaurant ID)
router
    .put('/:restaurantId/prep-item/complete', (0, asyncHandler_1.default)(IngredientController.completePrepItem));
// Update minimum stock level for an ingredient (updated to include restaurant ID)
router
    .put('/:restaurantId/minstock/:ingredientId', (0, asyncHandler_1.default)(IngredientController.updateMinStock));
// Get out of stock items for a restaurant
router
    .get('/outofstock/:restaurantId', (0, asyncHandler_1.default)(IngredientController.getOutOfStockItems));
// Update notification threshold for a user (updated to include restaurant ID)
router
    .put('/:restaurantId/notification-threshold', (0, asyncHandler_1.default)(IngredientController.updateNotificationThreshold));
// Get inventory transaction history
router
    .get('/transactions/:restaurantId', (0, asyncHandler_1.default)(IngredientController.getInventoryTransactions));
exports.default = router;
