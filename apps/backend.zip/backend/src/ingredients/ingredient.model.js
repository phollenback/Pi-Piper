"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IngredientSchema = void 0;
const { Schema } = require('express-validator');
exports.IngredientSchema = {
    ingredient_name: {
        notEmpty: true,
        errorMessage: 'Ingredient Item Name field cannot be empty.'
    },
    unit_of_measure: {
        notEmpty: false,
        errorMessage: 'Unit of Measurement field cannot be empty.'
    },
    cost_per_unit: {
        notEmpty: true,
        errorMessage: 'Price field cannot be empty.'
    },
    ingredient_category: {
        notEmpty: true,
        isInt: true,
        errorMessage: 'Ingredient category field cannot be empty.'
    }
};
