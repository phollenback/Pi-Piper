"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInventoryTransactions = exports.updateNotificationThreshold = exports.getOutOfStockItems = exports.updateMinStock = exports.completePrepItem = exports.getInventoryStatus = exports.IngredientController = exports.readSuggestions = exports.deleteIngredient = exports.updateIngredient = exports.createIngredient = exports.readPricing = exports.readInventory = exports.readIngredients = void 0;
const IngredientDal = __importStar(require("./ingredient.dal"));
const winston_middleware_1 = require("../middleware/winston.middleware");
const { validationResult } = require('express-validator');
const ingredient_service_1 = require("../services/ingredient.service");
// Retrieves all ingredients for a given restaurant.
const readIngredients = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][readIngredients][START]');
    try {
        const restaurantId = Number(req.params.restaurantId); // Extract restaurant ID from request parameters.
        const ingredients = yield IngredientDal.getIngredients(restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][readIngredients][SUCCESS]', { ingredients });
        res.status(200).json(ingredients);
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][readIngredients][ERROR]', { error });
        res.status(500).json({ message: 'Failed to fetch ingredients' });
    }
});
exports.readIngredients = readIngredients;
// Retrieves inventory information for a given restaurant.  (This is likely redundant with readIngredients)
const readInventory = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
});
exports.readInventory = readInventory;
// Retrieves pricing information for a given restaurant.
const readPricing = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][readPricing][START]');
    try {
        const restaurantId = Number(req.params.restaurantId);
        const pricing = yield IngredientDal.getAllPricing(restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][readPricing][SUCCESS]', { pricing });
        res.status(200).json(pricing);
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][readPricing][ERROR]', { error });
        res.status(500).json({ message: 'Failed to fetch pricing information' });
    }
});
exports.readPricing = readPricing;
// Creates a new ingredient for a given restaurant.
const createIngredient = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][createIngredient][START]');
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        winston_middleware_1.logger.error('[ingredient.controller][createIngredient][VALIDATION_ERROR]', { errors: errors.array() });
        return res.status(400).json({ errors: errors.array() });
    }
    try {
        const restaurantId = Number(req.params.restaurantId);
        const ingredientData = req.body;
        const newIngredient = yield IngredientDal.createIngredient(restaurantId, ingredientData);
        winston_middleware_1.logger.info('[ingredient.controller][createIngredient][SUCCESS]', { newIngredient }); // Changed Variable Name
        res.status(201).json(newIngredient); // Changed Variable Name
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][createIngredient][ERROR]', { error });
        res.status(500).json({ message: 'Failed to create ingredient' }); // More concise message
    }
});
exports.createIngredient = createIngredient;
// Updates an existing ingredient.
const updateIngredient = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][updateIngredient][START]');
    try {
        const ingredientId = Number(req.params.ingredientId);
        const restaurantId = Number(req.params.restaurantId);
        const ingredientData = req.body;
        winston_middleware_1.logger.info('[ingredient.controller][updateIngredient][INFO]', { restaurantId, ingredientId, ingredientData });
        const updatedIngredient = yield IngredientDal.updateIngredient(ingredientId, restaurantId, ingredientData);
        winston_middleware_1.logger.info('[ingredient.controller][updateIngredient][SUCCESS]', { updatedIngredient }); // Changed variable name
        res.status(200).json(updatedIngredient); // Changed variable name
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][updateIngredient][ERROR]', { error });
        res.status(500).json({ message: 'Failed to update ingredient' }); // More concise message
    }
});
exports.updateIngredient = updateIngredient;
// Deletes an ingredient.
const deleteIngredient = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][deleteIngredient][START]');
    try {
        const ingredientId = Number(req.params.ingredientId);
        const restaurantId = Number(req.params.restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][deleteIngredient][INFO]', { restaurantId, ingredientId });
        const result = yield IngredientDal.deleteIngredient(ingredientId, restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][deleteIngredient][SUCCESS]', { result });
        res.status(200).json(result);
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][deleteIngredient][ERROR]', { error });
        res.status(500).json({ message: 'Failed to delete ingredient' });
    }
});
exports.deleteIngredient = deleteIngredient;
// Retrieves ingredient suggestions for a given restaurant.
const readSuggestions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[ingredient.controller][readSuggestions][START]');
    try {
        const restaurantId = Number(req.params.restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][readSuggestions][INFO]', { restaurantId });
        const suggestions = yield IngredientDal.getSuggestions(restaurantId);
        winston_middleware_1.logger.info('[ingredient.controller][readSuggestions][SUCCESS]', { suggestions });
        res.status(200).json(suggestions);
    }
    catch (error) {
        winston_middleware_1.logger.error('[ingredient.controller][readSuggestions][ERROR]', { error });
        res.status(500).json({ message: 'Failed to fetch suggestions' });
    }
});
exports.readSuggestions = readSuggestions;
class IngredientController {
    static getInventoryStatus(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { restaurantId } = req.params;
                const inventoryData = yield ingredient_service_1.IngredientService.getInventoryStatus(parseInt(restaurantId));
                res.status(200).json(inventoryData);
            }
            catch (error) {
                res.status(500).json({ message: 'Failed to fetch inventory data', error });
            }
        });
    }
    static completePrepItem(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const restaurantId = Number(req.params.restaurantId);
                const { prepItemId } = req.body;
                yield ingredient_service_1.IngredientService.completePrepItem(prepItemId, restaurantId);
                res.status(200).json({ message: 'Prep item completed successfully' });
            }
            catch (error) {
                if (error === null || error === void 0 ? void 0 : error.message.includes('out of stock')) {
                    res.status(400).json({ message: error.message });
                }
                else {
                    res.status(500).json({ message: 'Failed to complete prep item', error });
                }
            }
        });
    }
    static updateMinStock(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const ingredientId = parseInt(req.params.ingredientId);
                const restaurantId = parseInt(req.params.restaurantId);
                const { minStock } = req.body;
                yield ingredient_service_1.IngredientService.updateIngredientThreshold(ingredientId, restaurantId, minStock);
                res.status(200).json({ message: 'Minimum stock level updated successfully' });
            }
            catch (error) {
                res.status(500).json({ message: 'Failed to update minimum stock level', error });
            }
        });
    }
    static getOutOfStockItems(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { restaurantId } = req.params;
                const outOfStockItems = yield ingredient_service_1.IngredientService.getOutOfStockItems(parseInt(restaurantId));
                res.status(200).json(outOfStockItems);
            }
            catch (error) {
                res.status(500).json({ message: 'Failed to fetch out of stock items', error });
            }
        });
    }
    static updateNotificationThreshold(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const restaurantId = parseInt(req.params.restaurantId);
                const { userId, threshold } = req.body;
                // Since we don't have a user preferences table yet, we'll just return success
                // In a real implementation, you would save this to a user preferences table
                // and associate it with the restaurant ID
                winston_middleware_1.logger.info('[ingredient.controller][updateNotificationThreshold][SUCCESS]', {
                    userId,
                    threshold,
                    restaurantId
                });
                res.status(200).json({
                    message: 'Notification threshold updated successfully',
                    restaurantId
                });
            }
            catch (error) {
                winston_middleware_1.logger.error('[ingredient.controller][updateNotificationThreshold][ERROR]', { error });
                res.status(500).json({ message: 'Failed to update notification threshold', error });
            }
        });
    }
    static getInventoryTransactions(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { restaurantId } = req.params;
                // Since we don't have a factInventoryTransaction table yet, we'll return an empty array
                // In a real implementation, you would query the factInventoryTransaction table
                res.status(200).json([]);
            }
            catch (error) {
                res.status(500).json({ message: 'Failed to fetch inventory transactions', error });
            }
        });
    }
}
exports.IngredientController = IngredientController;
exports.getInventoryStatus = IngredientController.getInventoryStatus;
exports.completePrepItem = IngredientController.completePrepItem;
exports.updateMinStock = IngredientController.updateMinStock;
exports.getOutOfStockItems = IngredientController.getOutOfStockItems;
exports.updateNotificationThreshold = IngredientController.updateNotificationThreshold;
exports.getInventoryTransactions = IngredientController.getInventoryTransactions;
