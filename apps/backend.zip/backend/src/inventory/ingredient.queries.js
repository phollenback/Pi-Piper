"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ingredientQueries = void 0;
exports.ingredientQueries = {
    completeTransaction: `
    
    `
};
