"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelInventoryTransaction = exports.completeInventoryTransaction = void 0;
const prepitems_queries_1 = require("../prepitems/prepitems.queries");
const winston_middleware_1 = require("../middleware/winston.middleware");
const pg_connector_1 = require("../services/pg.connector");
const completeInventoryTransaction = (itemName, restaurantId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[prepitem.dao][getPrepItemId][START]', { itemName, restaurantId });
    try {
        const prepItemId = yield (0, pg_connector_1.execute)(prepitems_queries_1.prepQueries.getPrepItemId, [itemName, restaurantId]);
        const prepItems = yield (0, pg_connector_1.execute)(prepitems_queries_1.prepQueries.getDailyPrepItems, [restaurantId]);
        winston_middleware_1.logger.info('[prepitem.dao][createDailyPrepItems][SUCCESS]', { prepItems });
        return prepItems;
    }
    catch (error) {
        winston_middleware_1.logger.error('[prepitem.dao][createDailyPrepItems][ERROR]', { error });
        throw error;
    }
});
exports.completeInventoryTransaction = completeInventoryTransaction;
const cancelInventoryTransaction = (restaurantId, item) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[inventory.dal][cancelInventoryTransaction][START]', { restaurantId, item });
    try {
        const result = yield (0, pg_connector_1.execute)(prepitems_queries_1.prepQueries.updateDailyPrepItem, [item.quantity, item.status, restaurantId, item.name]);
        winston_middleware_1.logger.info('[inventory.dal][cancelInventoryTransaction][SUCCESS]', { result });
        return result;
    }
    catch (error) {
        winston_middleware_1.logger.error('[inventory.dal][cancelInventoryTransaction][ERROR]', { error });
        throw error;
    }
});
exports.cancelInventoryTransaction = cancelInventoryTransaction;
