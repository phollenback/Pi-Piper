export const ingredientQueries = {
    completeTransaction:`
    
    `
}