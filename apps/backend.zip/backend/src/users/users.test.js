"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const users_routes_1 = __importDefault(require("./users.routes"));
const UserController = __importStar(require("./users.controller"));
// Update the UserController mock to include proper mock types
jest.mock('./users.controller', () => ({
    getUsers: jest.fn(),
    createUser: jest.fn(),
    updateUser: jest.fn(),
    deleteUser: jest.fn()
}));
// Mock express-validator
jest.mock('express-validator', () => ({
    body: () => ({
        isString: () => ({ notEmpty: () => ({}) }),
        isEmail: () => ({ notEmpty: () => ({}) }),
        notEmpty: () => ({})
    }),
    checkSchema: jest.fn(() => []),
    validationResult: jest.fn(() => ({
        isEmpty: () => true,
        array: () => []
    }))
}));
// Mock database connection
jest.mock('../db/connection', () => ({
    query: jest.fn()
}));
describe('Users API', () => {
    let app;
    beforeEach(() => {
        app = (0, express_1.default)();
        app.use(express_1.default.json());
        app.use('/users', users_routes_1.default);
        jest.clearAllMocks();
    });
    describe('GET /users/:restaurantId', () => {
        it('should return users for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockUsers = [
                { id: 1, name: 'John Doe', email: 'john@example.com', role: 'manager' },
                { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'staff' }
            ];
            UserController.getUsers.mockImplementation((req, res) => {
                res.status(200).json(mockUsers);
            });
            const response = yield (0, supertest_1.default)(app).get('/users/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockUsers);
            expect(UserController.getUsers).toHaveBeenCalled();
        }));
        it('should handle errors when fetching users', () => __awaiter(void 0, void 0, void 0, function* () {
            UserController.getUsers.mockImplementation((req, res) => {
                res.status(500).json({ message: 'Error fetching users' });
            });
            const response = yield (0, supertest_1.default)(app).get('/users/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ message: 'Error fetching users' });
            expect(UserController.getUsers).toHaveBeenCalled();
        }));
    });
    describe('POST /users', () => {
        it('should create a new user', () => __awaiter(void 0, void 0, void 0, function* () {
            const newUser = {
                name: 'New User',
                email: 'newuser@example.com',
                password: 'password123',
                role: 'staff',
                restaurantId: 1
            };
            const createdUser = Object.assign({ id: 3 }, newUser);
            UserController.createUser.mockImplementation((req, res) => {
                res.status(201).json(createdUser);
            });
            const response = yield (0, supertest_1.default)(app)
                .post('/users')
                .send(newUser);
            expect(response.status).toBe(201);
            expect(response.body).toEqual(createdUser);
            expect(UserController.createUser).toHaveBeenCalled();
        }));
    });
    describe('PUT /users/:userId', () => {
        it('should update an existing user', () => __awaiter(void 0, void 0, void 0, function* () {
            const updatedUser = {
                id: 1,
                name: 'Updated Name',
                email: 'updated@example.com',
                role: 'manager'
            };
            UserController.updateUser.mockImplementation((req, res) => {
                res.status(200).json(updatedUser);
            });
            const response = yield (0, supertest_1.default)(app)
                .put('/users/1')
                .send(updatedUser);
            expect(response.status).toBe(200);
            expect(response.body).toEqual(updatedUser);
            expect(UserController.updateUser).toHaveBeenCalled();
        }));
    });
    describe('DELETE /users/:userId', () => {
        it('should delete a user', () => __awaiter(void 0, void 0, void 0, function* () {
            UserController.deleteUser.mockImplementation((req, res) => {
                res.status(200).json({ message: 'User deleted successfully' });
            });
            const response = yield (0, supertest_1.default)(app).delete('/users/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual({ message: 'User deleted successfully' });
            expect(UserController.deleteUser).toHaveBeenCalled();
        }));
    });
});
