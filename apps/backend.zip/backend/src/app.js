"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
require("dotenv/config");
const connection_1 = require("./db/connection");
const winston_middleware_1 = require("./middleware/winston.middleware");
// ROUTES **************
const restaurant_routes_1 = __importDefault(require("./restaurants/restaurant.routes"));
const prepitems_routes_1 = __importDefault(require("./prepitems/prepitems.routes"));
const managers_routes_1 = __importDefault(require("./managers/managers.routes"));
const ingredient_routes_1 = __importDefault(require("./ingredients/ingredient.routes"));
const category_routes_1 = __importDefault(require("./categories/category.routes"));
const department_routes_1 = __importDefault(require("./departments/department.routes"));
const group_routes_1 = __importDefault(require("./groups/group.routes"));
const auth_routes_1 = __importDefault(require("./auth/auth.routes"));
const users_routes_1 = __importDefault(require("./users/users.routes"));
const recipe_routes_1 = __importDefault(require("./recipes/recipe.routes"));
const metrics_routes_1 = __importDefault(require("./metrics/metrics.routes"));
const restaurant_settings_routes_1 = __importDefault(require("./routes/restaurant-settings.routes"));
const app = (0, express_1.default)();
const port = process.env.PORT || 3000;
// Middleware
app.use((0, cors_1.default)());
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
app.use((0, helmet_1.default)());
app.use(winston_middleware_1.requestLogger); // Use request logger middleware
// Enhanced Database Initialization
const initializeDatabase = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        winston_middleware_1.logger.info('Initializing database connection...');
        const connected = yield (0, connection_1.testConnection)();
        if (connected) {
            winston_middleware_1.logger.info('Database connection established successfully');
            return true;
        }
        else {
            winston_middleware_1.logger.error('Database connection failed');
            return false;
        }
    }
    catch (err) {
        winston_middleware_1.logger.error('Database initialization failed', { error: err.message });
        throw err;
    }
});
// Start server only if database connection is successful
const startServer = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const dbInitialized = yield initializeDatabase();
        if (!dbInitialized) {
            winston_middleware_1.logger.error('Server cannot start without database connection');
            process.exit(1);
        }
        // Routes
        app.get('/', (req, res) => {
            res.send('<h1 style="text-align: center;">Welcome to the Pi-Piper API</h1>');
        });
        // Attach module routes
        app.use('/restaurants', restaurant_routes_1.default);
        app.use('/prepitems', prepitems_routes_1.default);
        app.use('/managers', managers_routes_1.default);
        app.use('/ingredients', ingredient_routes_1.default);
        app.use('/categories', category_routes_1.default);
        app.use('/departments', department_routes_1.default);
        app.use('/groups', group_routes_1.default);
        app.use('/auth', auth_routes_1.default);
        app.use('/users', users_routes_1.default);
        app.use('/recipes', recipe_routes_1.default);
        app.use('/metrics', metrics_routes_1.default);
        app.use('/restaurant-settings', restaurant_settings_routes_1.default);
        // Error Logging Middleware
        app.use((err, req, res, next) => {
            winston_middleware_1.logger.error(`${req.method} ${req.url} ${res.statusCode} - ${err.message}`);
            console.error(err.stack);
            res.status(500).send({ error: 'Something went wrong!' });
        });
        app.listen(port, () => {
            winston_middleware_1.logger.info(`Server started successfully on port ${port}`);
            console.log(`Pi Piper app listening at http://localhost:${port}`);
        });
    }
    catch (error) {
        winston_middleware_1.logger.error('Failed to start server', { error });
        process.exit(1);
    }
});
// Start the server
startServer();
