"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.up = up;
exports.down = down;
const drizzle_orm_1 = require("drizzle-orm");
const winston_middleware_1 = require("../../middleware/winston.middleware");
function up(db) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            winston_middleware_1.logger.info('[migration][0008_add_restaurant_settings] Running migration');
            // Create the dim_restaurant_settings table
            yield db.execute((0, drizzle_orm_1.sql) `
      CREATE TABLE IF NOT EXISTS dim_restaurant_settings (
        setting_id INT AUTO_INCREMENT PRIMARY KEY,
        restaurant_id INT NOT NULL,
        low_stock_threshold INT DEFAULT 40,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX settings_restaurant_id_idx (restaurant_id)
      )
    `);
            // Add foreign key constraint
            yield db.execute((0, drizzle_orm_1.sql) `
      ALTER TABLE dim_restaurant_settings
      ADD CONSTRAINT fk_settings_restaurant
      FOREIGN KEY (restaurant_id) REFERENCES dim_restaurant(restaurant_id)
      ON DELETE CASCADE
    `);
            // Insert default settings for existing restaurants
            yield db.execute((0, drizzle_orm_1.sql) `
      INSERT INTO dim_restaurant_settings (restaurant_id, low_stock_threshold)
      SELECT restaurant_id, 40 FROM dim_restaurant
      WHERE NOT EXISTS (
        SELECT 1 FROM dim_restaurant_settings rs 
        WHERE rs.restaurant_id = dim_restaurant.restaurant_id
      )
    `);
            winston_middleware_1.logger.info('[migration][0008_add_restaurant_settings] Migration completed successfully');
        }
        catch (error) {
            winston_middleware_1.logger.error('[migration][0008_add_restaurant_settings] Migration failed', { error });
            throw error;
        }
    });
}
function down(db) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            winston_middleware_1.logger.info('[migration][0008_add_restaurant_settings] Reverting migration');
            // Drop the table
            yield db.execute((0, drizzle_orm_1.sql) `DROP TABLE IF EXISTS dim_restaurant_settings`);
            winston_middleware_1.logger.info('[migration][0008_add_restaurant_settings] Migration reverted successfully');
        }
        catch (error) {
            winston_middleware_1.logger.error('[migration][0008_add_restaurant_settings] Migration reversion failed', { error });
            throw error;
        }
    });
}
