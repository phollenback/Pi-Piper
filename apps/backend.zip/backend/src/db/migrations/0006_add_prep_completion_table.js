"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.up = up;
exports.down = down;
const drizzle_orm_1 = require("drizzle-orm");
const connection_1 = require("../connection");
const winston_middleware_1 = require("../../middleware/winston.middleware");
function up() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            winston_middleware_1.logger.info('[migration][0006_add_prep_completion_table] Running migration');
            // Create the fact_prep_completion table
            yield connection_1.db.execute((0, drizzle_orm_1.sql) `
      CREATE TABLE IF NOT EXISTS fact_prep_completion (
        completion_id INT AUTO_INCREMENT PRIMARY KEY,
        restaurant_id INT NOT NULL,
        date_id INT NOT NULL,
        completion_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX prep_restaurant_date_idx (restaurant_id, date_id)
      )
    `);
            winston_middleware_1.logger.info('[migration][0006_add_prep_completion_table] Migration completed successfully');
        }
        catch (error) {
            winston_middleware_1.logger.error('[migration][0006_add_prep_completion_table] Migration failed', { error });
            throw error;
        }
    });
}
function down() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            winston_middleware_1.logger.info('[migration][0006_add_prep_completion_table] Rolling back migration');
            // Drop the fact_prep_completion table
            yield connection_1.db.execute((0, drizzle_orm_1.sql) `DROP TABLE IF EXISTS fact_prep_completion`);
            winston_middleware_1.logger.info('[migration][0006_add_prep_completion_table] Rollback completed successfully');
        }
        catch (error) {
            winston_middleware_1.logger.error('[migration][0006_add_prep_completion_table] Rollback failed', { error });
            throw error;
        }
    });
}
