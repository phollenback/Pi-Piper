"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.down = exports.up = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const up = (db) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('Running migration: 0007_add_inventory_transaction_table - UP');
        yield db.execute((0, drizzle_orm_1.sql) `
      CREATE TABLE IF NOT EXISTS fact_inventory_transaction (
        transaction_id INT AUTO_INCREMENT PRIMARY KEY,
        ingredient_id INT NOT NULL,
        restaurant_id INT NOT NULL,
        date_id INT NOT NULL,
        quantity_change DECIMAL(10, 2) NOT NULL,
        transaction_type VARCHAR(50) NOT NULL,
        reference_id INT,
        previous_quantity DECIMAL(10, 2),
        new_quantity DECIMAL(10, 2),
        notes TEXT,
        created_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX transaction_ingredient_id_idx (ingredient_id),
        INDEX transaction_restaurant_id_idx (restaurant_id),
        INDEX transaction_date_id_idx (date_id),
        INDEX transaction_type_idx (transaction_type)
      );
    `);
        console.log('Migration 0007_add_inventory_transaction_table completed successfully');
    }
    catch (error) {
        console.error('Error running migration 0007_add_inventory_transaction_table:', error);
        throw error;
    }
});
exports.up = up;
const down = (db) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('Running migration: 0007_add_inventory_transaction_table - DOWN');
        yield db.execute((0, drizzle_orm_1.sql) `
      DROP TABLE IF EXISTS fact_inventory_transaction;
    `);
        console.log('Rollback of migration 0007_add_inventory_transaction_table completed successfully');
    }
    catch (error) {
        console.error('Error rolling back migration 0007_add_inventory_transaction_table:', error);
        throw error;
    }
});
exports.down = down;
