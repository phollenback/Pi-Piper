"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.up = up;
exports.down = down;
const drizzle_orm_1 = require("drizzle-orm");
function up(db) {
    return __awaiter(this, void 0, void 0, function* () {
        // Create fact_restaurant_metrics table
        yield db.execute((0, drizzle_orm_1.sql) `
    CREATE TABLE IF NOT EXISTS fact_restaurant_metrics (
      metric_id INT AUTO_INCREMENT PRIMARY KEY,
      restaurant_id INT NOT NULL,
      date DATE NOT NULL,
      inventory_turnover DECIMAL(10, 2) NULL,
      avg_prep_time_hours DECIMAL(10, 2) NULL,
      overall_ingredient_price_avg DECIMAL(10, 2) NULL,
      monthly_cleaning_completion_pct DECIMAL(5, 2) NULL,
      weekly_cleaning_completion_pct DECIMAL(5, 2) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE(restaurant_id, date),
      INDEX restaurant_id_idx (restaurant_id),
      INDEX restaurant_date_idx (restaurant_id, date)
    )
  `);
        // Create dim_cleaning_task table
        yield db.execute((0, drizzle_orm_1.sql) `
    CREATE TABLE IF NOT EXISTS dim_cleaning_task (
      task_id INT AUTO_INCREMENT PRIMARY KEY,
      restaurant_id INT NOT NULL,
      task_name VARCHAR(255) NOT NULL,
      description TEXT NULL,
      frequency VARCHAR(20) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX restaurant_id_idx (restaurant_id)
    )
  `);
        // Create fact_cleaning_completion table
        yield db.execute((0, drizzle_orm_1.sql) `
    CREATE TABLE IF NOT EXISTS fact_cleaning_completion (
      completion_id INT AUTO_INCREMENT PRIMARY KEY,
      restaurant_id INT NOT NULL,
      task_id INT NOT NULL,
      date DATE NOT NULL,
      completed BOOLEAN DEFAULT FALSE,
      completed_by INT NULL,
      completed_at TIMESTAMP NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE(restaurant_id, task_id, date),
      INDEX restaurant_task_date_idx (restaurant_id, task_id, date),
      INDEX task_id_idx (task_id)
    )
  `);
    });
}
function down(db) {
    return __awaiter(this, void 0, void 0, function* () {
        yield db.execute((0, drizzle_orm_1.sql) `DROP TABLE IF EXISTS fact_cleaning_completion`);
        yield db.execute((0, drizzle_orm_1.sql) `DROP TABLE IF EXISTS dim_cleaning_task`);
        yield db.execute((0, drizzle_orm_1.sql) `DROP TABLE IF EXISTS fact_restaurant_metrics`);
    });
}
