"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteRecipe = exports.updateRecipe = exports.createRecipe = exports.readRecipeById = exports.readRecipes = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const RecipeDal = __importStar(require("./recipe.dal"));
// Get all recipes
const readRecipes = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.controller][readRecipes][START]');
    try {
        const restaurantId = Number(req.params.restaurantId);
        const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
        if (isNaN(restaurantId)) {
            return res.status(400).json({
                message: 'Invalid restaurant ID'
            });
        }
        const recipes = yield RecipeDal.getRecipes(restaurantId, categoryId);
        winston_middleware_1.logger.info('[recipe.controller][readRecipes][SUCCESS]', { count: recipes.length });
        res.status(200).json(recipes);
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.controller][readRecipes][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when fetching recipes'
        });
    }
});
exports.readRecipes = readRecipes;
// Get recipe by ID
const readRecipeById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.controller][readRecipeById][START]');
    try {
        const recipeId = Number(req.params.id);
        if (isNaN(recipeId)) {
            return res.status(400).json({
                message: 'Invalid recipe ID'
            });
        }
        const recipe = yield RecipeDal.getRecipeWithIngredientsById(recipeId);
        if (!recipe) {
            winston_middleware_1.logger.info('[recipe.controller][readRecipeById][NOT_FOUND]', { recipeId });
            return res.status(404).json({
                message: 'Recipe not found'
            });
        }
        winston_middleware_1.logger.info('[recipe.controller][readRecipeById][SUCCESS]');
        res.status(200).json(recipe);
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.controller][readRecipeById][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when fetching the recipe'
        });
    }
});
exports.readRecipeById = readRecipeById;
// Create a new recipe
const createRecipe = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.controller][createRecipe][START]');
    try {
        const { recipe, ingredients } = req.body;
        if (!recipe || !recipe.prepItemName || !ingredients || !Array.isArray(ingredients)) {
            winston_middleware_1.logger.info('[recipe.controller][createRecipe][VALIDATION_ERROR]');
            return res.status(400).json({
                message: 'Invalid recipe data. Recipe name and ingredients array are required.'
            });
        }
        const newRecipe = yield RecipeDal.insertRecipe(recipe, ingredients);
        winston_middleware_1.logger.info('[recipe.controller][createRecipe][SUCCESS]');
        res.status(201).json(newRecipe);
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.controller][createRecipe][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when creating the recipe'
        });
    }
});
exports.createRecipe = createRecipe;
// Update an existing recipe
const updateRecipe = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.controller][updateRecipe][START]');
    try {
        const recipeId = Number(req.params.id);
        const { recipe, ingredients } = req.body;
        if (isNaN(recipeId)) {
            return res.status(400).json({
                message: 'Invalid recipe ID'
            });
        }
        if (!recipe) {
            winston_middleware_1.logger.info('[recipe.controller][updateRecipe][VALIDATION_ERROR]');
            return res.status(400).json({
                message: 'Invalid recipe data. Recipe object is required.'
            });
        }
        const updatedRecipe = yield RecipeDal.modifyRecipe(recipeId, recipe, ingredients);
        if (!updatedRecipe) {
            winston_middleware_1.logger.info('[recipe.controller][updateRecipe][NOT_FOUND]', { recipeId });
            return res.status(404).json({
                message: 'Recipe not found'
            });
        }
        winston_middleware_1.logger.info('[recipe.controller][updateRecipe][SUCCESS]');
        res.status(200).json(updatedRecipe);
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.controller][updateRecipe][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when updating the recipe'
        });
    }
});
exports.updateRecipe = updateRecipe;
// Delete a recipe
const deleteRecipe = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.controller][deleteRecipe][START]');
    try {
        const recipeId = Number(req.params.id);
        if (isNaN(recipeId)) {
            return res.status(400).json({
                message: 'Invalid recipe ID'
            });
        }
        const deleted = yield RecipeDal.removeRecipe(recipeId);
        if (!deleted) {
            winston_middleware_1.logger.info('[recipe.controller][deleteRecipe][NOT_FOUND]', { recipeId });
            return res.status(404).json({
                message: 'Recipe not found'
            });
        }
        winston_middleware_1.logger.info('[recipe.controller][deleteRecipe][SUCCESS]');
        res.status(200).json({
            message: 'Recipe deleted successfully'
        });
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.controller][deleteRecipe][ERROR]', { error });
        res.status(500).json({
            message: 'There was an error when deleting the recipe'
        });
    }
});
exports.deleteRecipe = deleteRecipe;
