"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeRecipe = exports.modifyRecipe = exports.insertRecipe = exports.getRecipeWithIngredientsById = exports.getRecipes = void 0;
const winston_middleware_1 = require("../middleware/winston.middleware");
const connection_1 = require("../db/connection");
const schema_1 = require("../db/schema");
const drizzle_orm_1 = require("drizzle-orm");
const drizzle_orm_2 = require("drizzle-orm");
// Get all recipes with their ingredients
const getRecipes = (restaurantId, categoryId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.dal][getRecipes][START]', { restaurantId, categoryId });
    try {
        // Build the query conditions
        let conditions = [];
        if (restaurantId) {
            conditions.push((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.restaurantId, restaurantId));
        }
        if (categoryId) {
            conditions.push((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.itemCategory, categoryId));
        }
        // Get all prep items matching the conditions
        const prepItems = conditions.length > 0
            ? yield connection_1.db.select().from(schema_1.dimPrepItem).where((0, drizzle_orm_1.and)(...conditions))
            : yield connection_1.db.select().from(schema_1.dimPrepItem);
        // Get all prep item IDs
        const prepItemIds = prepItems.map(item => item.prepItemId);
        // Get all ingredients for these prep items in a single query
        const allIngredients = prepItemIds.length > 0
            ? yield connection_1.db
                .select({
                prepIngredientId: schema_1.factPrepItemIngredients.prepIngredientId,
                prepItemId: schema_1.factPrepItemIngredients.prepItemId,
                ingredientId: schema_1.factPrepItemIngredients.ingredientId,
                quantity: schema_1.factPrepItemIngredients.quantity,
                unit: schema_1.factPrepItemIngredients.unit,
                ingredient: {
                    ingredientId: schema_1.dimIngredient.ingredientId,
                    ingredientName: schema_1.dimIngredient.ingredientName,
                    unit: schema_1.dimIngredient.unit,
                    unitPrice: schema_1.dimIngredient.unitPrice,
                    isActive: schema_1.dimIngredient.isActive
                }
            })
                .from(schema_1.factPrepItemIngredients)
                .leftJoin(schema_1.dimIngredient, (0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.ingredientId, schema_1.dimIngredient.ingredientId))
                .where((0, drizzle_orm_1.inArray)(schema_1.factPrepItemIngredients.prepItemId, prepItemIds))
            : [];
        // Group ingredients by prep item ID
        const ingredientsByPrepItemId = allIngredients.reduce((acc, ingredient) => {
            const prepItemId = ingredient.prepItemId;
            if (!acc[prepItemId]) {
                acc[prepItemId] = [];
            }
            acc[prepItemId].push(ingredient);
            return acc;
        }, {});
        // Combine prep items with their ingredients
        const recipesWithIngredients = prepItems.map(prepItem => {
            // Add procedure field from description
            const procedure = prepItem.description || '';
            return Object.assign(Object.assign({}, prepItem), { ingredients: ingredientsByPrepItemId[prepItem.prepItemId] || [], procedure });
        });
        winston_middleware_1.logger.info('[recipe.dal][getRecipes][SUCCESS]', { count: recipesWithIngredients.length });
        return recipesWithIngredients;
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.dal][getRecipes][ERROR]', { error });
        throw error;
    }
});
exports.getRecipes = getRecipes;
// Get a specific recipe by ID with its ingredients
const getRecipeWithIngredientsById = (prepItemId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.dal][getRecipeWithIngredientsById][START]', { prepItemId });
    try {
        // Get the prep item
        const prepItem = yield connection_1.db
            .select()
            .from(schema_1.dimPrepItem)
            .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId))
            .then(items => items[0]);
        if (!prepItem) {
            winston_middleware_1.logger.info('[recipe.dal][getRecipeWithIngredientsById][NOT_FOUND]', { prepItemId });
            return null;
        }
        // Get the ingredients for this prep item
        const ingredients = yield connection_1.db
            .select({
            prepIngredientId: schema_1.factPrepItemIngredients.prepIngredientId,
            prepItemId: schema_1.factPrepItemIngredients.prepItemId,
            ingredientId: schema_1.factPrepItemIngredients.ingredientId,
            quantity: schema_1.factPrepItemIngredients.quantity,
            unit: schema_1.factPrepItemIngredients.unit,
            ingredient: {
                ingredientId: schema_1.dimIngredient.ingredientId,
                ingredientName: schema_1.dimIngredient.ingredientName,
                unit: schema_1.dimIngredient.unit,
                unitPrice: schema_1.dimIngredient.unitPrice,
                isActive: schema_1.dimIngredient.isActive
            }
        })
            .from(schema_1.factPrepItemIngredients)
            .leftJoin(schema_1.dimIngredient, (0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.ingredientId, schema_1.dimIngredient.ingredientId))
            .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
        // Get category information if available
        let category = null;
        if (prepItem.itemCategory) {
            category = yield connection_1.db
                .select()
                .from(schema_1.dimCategory)
                .where((0, drizzle_orm_1.eq)(schema_1.dimCategory.categoryId, prepItem.itemCategory))
                .then(categories => categories[0] || null);
        }
        // Add procedure field from description
        const procedure = prepItem.description || '';
        const recipeWithIngredients = Object.assign(Object.assign({}, prepItem), { ingredients,
            category,
            procedure });
        winston_middleware_1.logger.info('[recipe.dal][getRecipeWithIngredientsById][SUCCESS]');
        return recipeWithIngredients;
    }
    catch (error) {
        winston_middleware_1.logger.error('[recipe.dal][getRecipeWithIngredientsById][ERROR]', { error });
        throw error;
    }
});
exports.getRecipeWithIngredientsById = getRecipeWithIngredientsById;
// Insert a new recipe with ingredients
const insertRecipe = (recipe, ingredients) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.dal][insertRecipe][START]');
    // Start a transaction
    return yield connection_1.db.transaction((tx) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            // Insert the prep item
            const result = yield tx
                .insert(schema_1.dimPrepItem)
                .values({
                name: recipe.name,
                description: recipe.description,
                itemCategory: recipe.itemCategory,
                kitchenDepartmentId: recipe.kitchenDepartmentId,
                restaurantId: recipe.restaurantId
            });
            // Get the last inserted ID
            const [{ insertId }] = yield tx.execute((0, drizzle_orm_2.sql) `SELECT LAST_INSERT_ID() as insertId`);
            const prepItemId = Number(insertId);
            // Get the newly inserted prep item
            const newPrepItem = yield tx
                .select()
                .from(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId))
                .then(items => items[0]);
            // Insert the ingredients
            if (ingredients && ingredients.length > 0) {
                yield tx
                    .insert(schema_1.factPrepItemIngredients)
                    .values(ingredients.map(ingredient => ({
                    prepItemId: prepItemId,
                    ingredientId: ingredient.ingredientId,
                    quantity: String(ingredient.quantity),
                    unit: ingredient.unit
                })));
            }
            // Get the complete recipe with ingredients
            const completeRecipe = yield (0, exports.getRecipeWithIngredientsById)(prepItemId);
            winston_middleware_1.logger.info('[recipe.dal][insertRecipe][SUCCESS]', { prepItemId });
            return completeRecipe;
        }
        catch (error) {
            winston_middleware_1.logger.error('[recipe.dal][insertRecipe][ERROR]', { error });
            throw error;
        }
    }));
});
exports.insertRecipe = insertRecipe;
// Update an existing recipe
const modifyRecipe = (prepItemId, recipe, ingredients) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.dal][modifyRecipe][START]', { prepItemId });
    // Start a transaction
    return yield connection_1.db.transaction((tx) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        try {
            // Check if the recipe exists
            const existingRecipe = yield tx
                .select()
                .from(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId))
                .then(items => items[0]);
            if (!existingRecipe) {
                winston_middleware_1.logger.info('[recipe.dal][modifyRecipe][NOT_FOUND]', { prepItemId });
                return null;
            }
            // Update the prep item
            yield tx
                .update(schema_1.dimPrepItem)
                .set({
                name: (_a = recipe.name) !== null && _a !== void 0 ? _a : existingRecipe.name,
                description: (_b = recipe.description) !== null && _b !== void 0 ? _b : existingRecipe.description,
                itemCategory: (_c = recipe.itemCategory) !== null && _c !== void 0 ? _c : existingRecipe.itemCategory,
                kitchenDepartmentId: (_d = recipe.kitchenDepartmentId) !== null && _d !== void 0 ? _d : existingRecipe.kitchenDepartmentId,
                restaurantId: (_e = recipe.restaurantId) !== null && _e !== void 0 ? _e : existingRecipe.restaurantId
            })
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId));
            // Update ingredients if provided
            if (ingredients) {
                // Delete existing ingredients
                yield tx
                    .delete(schema_1.factPrepItemIngredients)
                    .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
                // Insert new ingredients
                if (ingredients.length > 0) {
                    yield tx
                        .insert(schema_1.factPrepItemIngredients)
                        .values(ingredients.map(ingredient => ({
                        prepItemId: prepItemId,
                        ingredientId: ingredient.ingredientId,
                        quantity: String(ingredient.quantity),
                        unit: ingredient.unit
                    })));
                }
            }
            // Get the updated recipe with ingredients
            const updatedRecipe = yield (0, exports.getRecipeWithIngredientsById)(prepItemId);
            winston_middleware_1.logger.info('[recipe.dal][modifyRecipe][SUCCESS]', { prepItemId });
            return updatedRecipe;
        }
        catch (error) {
            winston_middleware_1.logger.error('[recipe.dal][modifyRecipe][ERROR]', { error });
            throw error;
        }
    }));
});
exports.modifyRecipe = modifyRecipe;
// Delete a recipe
const removeRecipe = (prepItemId) => __awaiter(void 0, void 0, void 0, function* () {
    winston_middleware_1.logger.info('[recipe.dal][removeRecipe][START]', { prepItemId });
    // Start a transaction
    return yield connection_1.db.transaction((tx) => __awaiter(void 0, void 0, void 0, function* () {
        try {
            // Check if the recipe exists
            const existingRecipe = yield tx
                .select()
                .from(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId))
                .then(items => items[0]);
            if (!existingRecipe) {
                winston_middleware_1.logger.info('[recipe.dal][removeRecipe][NOT_FOUND]', { prepItemId });
                return false;
            }
            // Delete ingredients first (foreign key constraint)
            yield tx
                .delete(schema_1.factPrepItemIngredients)
                .where((0, drizzle_orm_1.eq)(schema_1.factPrepItemIngredients.prepItemId, prepItemId));
            // Delete the prep item
            yield tx
                .delete(schema_1.dimPrepItem)
                .where((0, drizzle_orm_1.eq)(schema_1.dimPrepItem.prepItemId, prepItemId));
            winston_middleware_1.logger.info('[recipe.dal][removeRecipe][SUCCESS]', { prepItemId });
            return true;
        }
        catch (error) {
            winston_middleware_1.logger.error('[recipe.dal][removeRecipe][ERROR]', { error });
            throw error;
        }
    }));
});
exports.removeRecipe = removeRecipe;
