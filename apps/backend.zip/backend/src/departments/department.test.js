"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const department_routes_1 = __importDefault(require("./department.routes"));
const DepartmentController = __importStar(require("./department.controller"));
// Mock the department controller
jest.mock('./department.controller', () => ({
    readDepartments: jest.fn(),
    readDepProgress: jest.fn()
}));
// Mock the database connection
jest.mock('../services/pg.connector', () => ({
    pool: {
        end: jest.fn()
    }
}));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use('/departments', department_routes_1.default);
describe('Department API', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('GET /departments/:restaurantId', () => {
        it('should return departments for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockDepartments = [
                { department_id: 1, department_name: 'Kitchen', restaurant_id: 1 },
                { department_id: 2, department_name: 'Bar', restaurant_id: 1 }
            ];
            // Mock the readDepartments function
            jest.mocked(DepartmentController.readDepartments).mockImplementation((req, res) => {
                res.status(200).json(mockDepartments);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/departments/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockDepartments);
            expect(DepartmentController.readDepartments).toHaveBeenCalled();
        }));
        it('should handle errors when fetching departments', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the readDepartments function to simulate an error
            jest.mocked(DepartmentController.readDepartments).mockImplementation((req, res) => {
                res.status(500).json({ error: 'Failed to fetch departments' });
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/departments/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ error: 'Failed to fetch departments' });
        }));
    });
    describe('GET /departments/daily/:restaurantId', () => {
        it('should return department progress for a restaurant', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockProgress = [
                { department_id: 1, department_name: 'Kitchen', total_items: 10, completed_items: 5 },
                { department_id: 2, department_name: 'Bar', total_items: 8, completed_items: 3 }
            ];
            // Mock the readDepProgress function
            jest.mocked(DepartmentController.readDepProgress).mockImplementation((req, res) => {
                res.status(200).json(mockProgress);
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/departments/daily/1');
            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockProgress);
            expect(DepartmentController.readDepProgress).toHaveBeenCalled();
        }));
        it('should handle errors when fetching department progress', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock the readDepProgress function to simulate an error
            jest.mocked(DepartmentController.readDepProgress).mockImplementation((req, res) => {
                res.status(500).json({ error: 'Failed to fetch department progress' });
                return Promise.resolve();
            });
            const response = yield (0, supertest_1.default)(app).get('/departments/daily/1');
            expect(response.status).toBe(500);
            expect(response.body).toEqual({ error: 'Failed to fetch department progress' });
        }));
    });
});
